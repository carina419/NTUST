install.packages("MASS")
install.packages("cluster")
install.packages("clusterSim")

library(MASS)
library(cluster)
library(clusterSim)

data(iris)
#iris.nm<-data.Normalization(iris[, -5], type="n4", normalization="column")

gender_size<- read.csv("gender_size.csv")
#gender.nm<-data.Normalization(gender_size[, -4], type="n4", normalization="column")

min.nc=2#不能取最小值1因1沒意義
max.nc=8#嘗試從2-8cluster找最好的(透過輸出)

#K means// K is the number of clusters
result0= kmeans(iris[,1:4], center=3)#用1-4features的資料
print(result0)
result0$centers
plot(iris)

table(iris$Species, result0$cluster)
plot(iris[,1:2], pch=result0$cluster, col=result0$cluster)
points(result0$centers[,1:2], col=1:3, pch=8)
#pch point characteristics

plot(iris[,3:4], pch=result0$cluster, col=result0$cluster)
points(result0$centers[,3:4], col=1:3, pch=8)

KM=array(0, c(max.nc-min.nc+1, 2))
for (nc in min.nc : max.nc)
  { 
  fitkm=kmeans(iris[, -5], center=nc)
  KM[nc-(min.nc-1), 1]= fitkm$betweenss/fitkm$tot.withinss#組間/組內=f的概念(要最小化組內變異，但最大化組間變異)
  KM[nc-(min.nc-1), 2]= index.DB(iris[,-5], fitkm$cluster, centrotypes="centroids", p=2)$DB
  }
which(KM[,1]==max(KM[,1])) #the larger the better
which(KM[,2]==min(KM[,2])) #the smaller the better

install.packages("NbClust")
library(NbClust)
NbClust(iris[,1:4], distance="euclidean", min.nc=2, max.nc=8, method="kmeans", index="all")

####K medoids#############################
PM=array(0, c(max.nc-min.nc+1,2))
for (nc in min.nc : max.nc)
{ fitpm=pam(iris[,-5], nc)
  PM[nc-(min.nc-1), 1]= index.DB(iris[,-5], fitpm$clustering, centrotypes="centroids", p=2)$DB
  PM[nc-(min.nc-1), 2]= index.DB(iris[,-5], fitpm$clustering, dist(iris[,-5]), centrotypes="medoids", p=2)$DB
}
which(PM[,1]==min(PM[,1]))
which(PM[,2]==min(PM[,2]))

result1=pam(iris[,-5], 2)
print(result1)
result1$medoids#最具代表性的資料樣本
table(iris$Species, result1$cluster)

plot(iris[,1:2], pch=result1$cluster, col=result1$cluster)
points(result1$medoids[,1:2], col=1:2, pch=8)

plot(iris[,3:4], pch=result1$cluster, col=result1$cluster)
points(result1$medoids[,3:4], col=1:2, pch=8)

##############C means#################################################
install.packages("e1071")
#cmeans
library(e1071)

CM= array(0, c(max.nc-min.nc+1, 2))
for (nc in min.nc : max.nc)
{ 
  fitcm=cmeans(iris[,-5], centers=nc, m=2, verbose=TRUE, method="cmeans")
  CM[nc-(min.nc-1), 1]= fclustIndex(fitcm, iris[,-5], index="xie.beni")
  CM[nc-(min.nc-1), 2]= fclustIndex(fitcm, iris[,-5], index="fukuyama.sugeno")
}#隨著iteration，error會越來越小!

which(CM[,1]==min(CM[,1])) #the smaller the better
which(CM[,2]==min(CM[,2])) #the smaller the better

result2<- cmeans(iris[,-5], center=2, m=2, iter.max=200, verbose=T, method="cmeans")
print(result2)
table(iris$Species, result2$cluster)

result2$centers
plot(iris[,1:2], pch=result2$cluster, col=result2$cluster)
points(result2$centers[,1:2], col=1:2, pch=8)

plot(iris[,3:4], pch=(result2$cluster), col=result2$cluster)
points(result2$centers[,3:4], col=1:2, pch=8)

##chapter4 Hierarchical clustering#################################
id=sample(1:nrow(iris), 0.2*nrow(iris)) #for visualization

result3=hclust(dist(iris[id, -5]), method="average")
print(result3)
plot(result3, labels=iris$Species[id])
group3=cutree(result3, k=3)

print(group3)
table(group3)
rect.hclust(result3, k=3, border="red")#用紅框分群

test<-iris[id, -5]
group_HC1<-test[which(group3==1),]
#上一行代表show group 1的樣本(14個)
group_HC1
#上一行代表show group 1的樣本(14個)
HC= array(0, c(max.nc-min.nc+1,2))
for (nc in min.nc : max.nc)
{
  fithc1 <- hclust(dist(iris[, -5]), method="average")
  ct1 <- cutree(fithc1, k=nc)
  HC[nc-(min.nc-1), 1] <- index.DB(iris[, -5], ct1, centrotypes="centroids")$DB
  
  fithc2 <- hclust(dist(iris[, -5]), method="ward.D")
  ct2 <- cutree(fithc2, k=nc)
  HC[nc-(min.nc-1), 2] <- index.DB(iris[, -5], ct2, centrotypes="centroids")$DB
}
which(HC[,1]==min(HC[,1]))
which(HC[,2]==min(HC[,2]))

HC= array(0, c(max.nc-min.nc+1,2))
for (nc in min.nc : max.nc)
{
  fithc1 <- hclust(dist(iris[, -5]), method="single")
  ct1 <- cutree(fithc1, k=nc)
  HC[nc-(min.nc-1), 1] <- index.DB(iris[, -5], ct1, centrotypes="centroids")$DB
  
  fithc2 <- hclust(dist(iris[, -5]), method="complete")
  ct2 <- cutree(fithc2, k=nc)
  HC[nc-(min.nc-1), 2] <- index.DB(iris[, -5], ct2, centrotypes="centroids")$DB
}
which(HC[,1]==min(HC[,1]))
which(HC[,2]==min(HC[,2]))

##### Clustering NBA dataset (National Basketball Association)
nba<-read.csv("2011NBA.csv", header=T, sep=",")
nba[1:5,]
nba.clus<-nba[,-c(1,2)] #remove text columns: player & division
means<-apply(nba.clus, 2, mean) #get mean?A2: column?A1:row
sds<-apply(nba.clus, 2, sd) #get standard deviation?A2:column?A1:row

nba.clus<-scale(nba.clus, center=means, scale=sds)  #using Z-score normalization
nba.dist<-dist(nba.clus, method="euclidean") #Euclidean distance
nba.fit<-hclust(nba.dist, method="ward.D2") #?HWard-distance based clustering

names(nba.fit) ###?????o??(points per game)?B?????x?O(rebounds)?B?????U??(assists per game)?B????????(blocks per game)?B?????ۺI(steals per game) 
plot(nba.fit, labels=nba$player, main="NBA TOP25") #tree-based dendrograms
rect.hclust(nba.fit, k=5, border="red") #Using redlines to define boundaries

cluster5<-cutree(nba.fit, k=5) #???w???s?��R??5?s (assigned by 5 clusters)
nba$player[cluster5==1] #?I?s?ݩ??Ĥ@???s???��R???G (show cluster 1)
sapply(unique(cluster5), function(a)nba$player[cluster5==a]) #show all clusters

nba.new<-cbind(nba, cluster5)  #insert new labels into original dataset
nba.new[1:5,]
nba.new$cluster5<-factor(nba.new$cluster5, levels=c(1:5), labels=c("scorer", "defender", "point-guard", "combo-guard", "power-forward"))  #rename the five groups as score (?o??)?Bdefender (???u)?Bguard (????)?Bcombo guard (??????)?Bpower forward (?j?e?W)

table(nba.new$division, nba.new$cluster5)  #Compare distribution in east/west regions
cor(nba[c(3:7)], use="pairwise") #correlation coefficient (?????Y?ƪ??B?P?w)
anova(lm(nba.new$ppg~factor(cluster5))) #one-way ANOVA (?????o?��P?y??????)

###Gaussian mixture clustering (EM expectation-maximization) clustering
#install.packages("mclust")
library(mclust) #BIC: Bayesian information criteria

fitEM1=Mclust(iris[,-5])
summary(fitEM1, parameters=TRUE)

result4=Mclust(iris[,-5], G=2)
result4$parameters
result4$classification
table(iris[,5],result4$classification)

fitEM1$BIC
# (1:BIC, 2:classification, 3:uncertainty, 4:density, 0:exit)

#Visualization (??ı?ƳB?z)
iris.BIC=mclustBIC(iris[,-5], G=seq(from=1, to=9, by=1))
iris.BIC
plot(iris.BIC)

iris.BICsum=summary(iris.BIC, data=iris[,-5])
iris.BICsum
names(iris.BICsum)
iris.BICsum$classification

mclust2Dplot(iris[, 3:4], classification=iris.BICsum$classification)
iris.dens1=densityMclust(iris[, 3:4])
plot(iris.dens1, iris[, 3:4], col="blue", nlevels=15)

iris.dens2=densityMclust(iris[,3:4])
plot(iris.dens2, iris[, 3:4], type="persp", col="red")

######gender dataset without normalization
attach(gender_size)
fitEM2=Mclust(gender_size[,-4])
summary(fitEM2, parameters=TRUE)
result5=Mclust(gender_size[,-4], G=3) #the best split is three

result5$parameters
result5$classification
table(gender_size$Gender, fitEM2$classification)

plot(gender_size[,1:2], pch=result5$classification, col=result5$classification)
plot(gender_size[,2:3], pch=result5$classification, col=result5$classification)
plot(gender_size[,1], gender_size[,3], pch=result5$classification, col=result5$classification)
plot(gender_size[,1:3], pch=result5$classification, col=result5$classification)

