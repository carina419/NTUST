package ntust.nui.ai.tool;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

/**
 *
 * @author bslin
 */
public class FileTool {
//    public interface ProcessSentence {
//        void process(String line);
//    }

    public static Set<String> loadLinesFromFile(File file) {
        Set<String> lines = new HashSet();
        assert (file.isFile());
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF8"))) {
            Consumer<String> lineProcessor = (String line) -> {
                if (!line.isEmpty() && !lines.contains(line)) {
                    lines.add(line);
                }
            };
            reader.lines().forEach(lineProcessor);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lines;
    }
    
    public static void loadTextFile(File file, Consumer<String> proc) {
        try(BufferedReader input = new BufferedReader(new InputStreamReader(new FileInputStream(file), "big5"))) {
            input.lines().forEach(proc);
        } catch (FileNotFoundException x) {
            System.out.println("file " + file.getPath() + " not found");
        } catch (IOException x) {
            System.out.println("file " + file.getPath() + " io exception");
        }
    }
    public static void processPath(File dir, Consumer<String> proc) {

        if(dir.isFile()) {
            loadTextFile(dir, proc);
            return;
        }
        for (File file : dir.listFiles()) {
            processPath(file, proc);
        }
    }
    public static void writeObjectListToFile(List objs, String filename) {
        File file = new File(filename);

        try {
            ObjectOutputStream objOutputStream = new ObjectOutputStream(new FileOutputStream(file));
            for (Object obj : objs) {
                objOutputStream.writeObject(obj);
            }
            objOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void writeObjectToFile(Object obj, String filename) {
        List list = new LinkedList();
        list.add(obj);
        writeObjectListToFile(list, filename);
    }

    public static List readObjectListFromFile(String filename) {
        List list = new ArrayList();
        try {
            File file = new File(filename);
            FileInputStream fileInputStream = new FileInputStream(file);
            ObjectInputStream objInputStream = new ObjectInputStream(fileInputStream);

            while (fileInputStream.available() > 0) {
                list.add(objInputStream.readObject());
            }
            objInputStream.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }

    public static Object readObjectFromFile(String filename) {
        List list = readObjectListFromFile(filename);
        return list.isEmpty() ? null: list.get(0);
    }
}
