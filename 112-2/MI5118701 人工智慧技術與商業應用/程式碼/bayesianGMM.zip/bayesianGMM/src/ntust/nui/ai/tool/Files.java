package ntust.nui.ai.tool;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * An Iterable class that can traverse all files under the assigned path.
 *
 * @author Bor-Shen Lin in NTUST.
 */
public class Files implements Iterable<File> {

	private final FileIterator iterator;

	public Files(File dir) throws FileNotFoundException {
		if (!dir.exists()) {
			throw new FileNotFoundException();
		}
		iterator = new FileIterator(dir);
	}

	@Override
	public Iterator iterator() {
		iterator.reset();
		return iterator;
	}

	@Override
	public String toString() {
		StringBuilder s = new StringBuilder("[");
		iterator.reset();
		while (iterator.hasNext()) {
			if (s.length() > 1) {
				s.append(",");
			}
			s.append(iterator.next());
		}
		s.append("]");
		return s.toString();
	}

	public Stream<File> serialStream() {
		return StreamSupport.stream(spliterator(), false);
	}

	public Stream<File> parallelStream() {
		return StreamSupport.stream(spliterator(), true);
	}

	public static void main(String args[]) throws FileNotFoundException {

		Files files = new Files(new File("D:\\trainingdata"));
		for (File file : files) {
			System.out.println("handle: " + file);
		}
//        for (File file : files) {
//            System.out.println("handle: " + file);
//        }
//        System.out.println("files " + files);

//        List<File> files2 = new Filter<File>() {
//
//            public boolean accept(File file) {
//                return file.getName().endsWith(".txt");
//            }
//        }.process(files);
//        System.out.println("txt files " + files2);
	}

	public static void test() {

		FileIterator iterator = new FileIterator(new File("D:\\java"));
		while (iterator.hasNext()) {
			File file = iterator.next();
			System.out.println(file);
			if (file.getName().endsWith(".class")) {
				iterator.remove();
			}
		}
	}
}
