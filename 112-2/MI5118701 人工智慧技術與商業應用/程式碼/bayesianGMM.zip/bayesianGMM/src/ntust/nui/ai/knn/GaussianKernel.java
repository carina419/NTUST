package ntust.nui.ai.knn;

import ntust.nui.ai.common.Kernel;

/**
 *
 * @author borson
 */
public class GaussianKernel implements Kernel<double[]> {

    double w;

    public GaussianKernel(double w) {
        this.w = w;
    }

    @Override
    public double similarity(double[] x, double[] y) {
        int d = x.length;
        double delta = distance(x, y) / w;
        double distance = 0;
        distance -= delta * delta;
        distance -= 4 * d * Math.log(w) + d * Math.log(2 * Math.PI);
        return Math.exp(distance / 2);
    }

    private static double distance(double a[], double b[]) {
        double sum = 0;
        for (int i = 0, n = a.length; i < n; i++) {
            double diff = a[i] - b[i];
            sum += diff * diff;
        }
        return Math.sqrt(sum);
    }
}
