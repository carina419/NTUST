
package ntust.nui.ai.gmm;

/**
 *
 * @author bslin
 */
import ntust.nui.ai.common.PointND;
import ntust.nui.ai.common.Point;
import java.util.Collection;

public class GaussianDiag extends Gaussian<GaussianDiag.CovarianceDiagonal> {
	public static double varLowerBound = 1e-4;
    public static class CovarianceDiagonal extends PointND implements Gaussian.Covariance {

        private static final long serialVersionUID = 4;

        public CovarianceDiagonal(int dim) {
            super(dim);
        }

        private CovarianceDiagonal(CovarianceDiagonal prototype) {
            super(prototype);
        }
        public String toString() {
            StringBuilder s = new StringBuilder();
            for(int i = 0; i < coord.length; i++) {
                if(i > 0) s.append(" ");
                s.append(coord[i]);
            }
            return s.toString();
        }
        @Override
        public Object clone() {
            return new CovarianceDiagonal(this);
        }

        @Override
        public void clear() {
            for (int i = 0; i < coord.length; i++) {
                coord[i] = 0.0;
            }
        }

        @Override
        public double get(int row, int col) {
            if (row != col) {
                return 0.0;
            }
            return coord[row];
        }

        @Override
        public double det() {
            double product = 1;
            for(int i = 0; i < coord.length; i++) {
                product *= coord[i];
            }
            return product;
        }
        @Override
        public double average() {
            double sum = 0;
            for(int i = 0; i < coord.length; i++) {
                sum += coord[i];
            }
            return sum / coord.length;
        }
    }

    public GaussianDiag() {
        super();
    }


    public GaussianDiag(PointND m, CovarianceDiagonal c) {
        super(m, c);
    }


    protected GaussianDiag(GaussianDiag prototype) {
        super(prototype);
    }

    @Override
    public Object clone() {
        return new GaussianDiag(this);
    }

    @Override
    public double getProbability(Point x) {
        return Math.exp(getLogProbability(x));
    }

    @Override
    protected double findGconst() {
        if (mean == null || cov == null) {
            System.err.println("mean/var not yet set!");
        }
        double sum = Math.log(2 * Math.PI) * cov.coord.length;
        for (int i = 0; i < cov.coord.length; i++) {
            sum += Math.log(cov.coord[i]);
        }
        return sum;
    }

    @Override
    protected void findMeanCov(Collection<Point> points) {
//		System.out.println("points size "+points.size());
        for (Point point : points) {
            if (mean == null) {
                mean = new PointND(point.getCoordinates().length);
                cov = new CovarianceDiagonal(point.getCoordinates().length);
            }
            double coord[] = point.getCoordinates();
            for (int i = 0; i < mean.coord.length; i++) {
                mean.coord[i] += coord[i];
                cov.coord[i] += coord[i] * coord[i];
            }
        }
        for (int i = 0; i < mean.coord.length; i++) {
            mean.coord[i] /= points.size();
            cov.coord[i] /= points.size();
            cov.coord[i] -= mean.coord[i] * mean.coord[i];
			if(cov.coord[i] < varLowerBound)cov.coord[i] = varLowerBound;
        }
        gconst = findGconst();
    }

    @Override
    public double getLogProbability(Point x) {
        double sum = gconst;
        double coord[] = x.getCoordinates();
        for (int i = 0; i < coord.length; i++) {
            double diff = coord[i] - mean.coord[i];
            sum += diff * diff / cov.coord[i];
        }
        return -0.5 * sum;
    }

    @Override
    protected void update(double likelihood, Point x, Gaussian old) {
        assert(!Double.isNaN(likelihood));
        if (!mceTraining) {
            // EM training (Maximumn Likelihood Estimation)
            double coord[] = x.getCoordinates();
            for (int i = 0; i < mean.coord.length; i++) {
                mean.coord[i] += likelihood * coord[i];
            }
            for (int i = 0; i < cov.coord.length; i++) {
                cov.coord[i] += likelihood * coord[i] * coord[i];
            }
        } else {
            // MCE training (Minimum Classification Errors) with GPD
            double coord[] = x.getCoordinates();
            for (int i = 0; i < mean.coord.length; i++) {
                //double distance = (x.coord[i] - old.mean.coord[i]) / Math.sqrt(old.cov.get(i, i));
                double distance = (coord[i] - old.mean.coord[i]) / old.cov.get(i, i);
                double delta = epsilon * likelihood * distance;
                //double delta2 = epsilon * likelihood * (distance * distance - 1);
                //if (withinCluster) { // within cluster --> same direction
                    mean.coord[i] += delta;
                    //cov.coord[i] += delta2;
                //} else { // different cluster --> opposite direction
                    //mean.coord[i] -= delta;
                    //cov.coord[i] -= delta2;                    
                //}
            }
        }
    }

    @Override
    protected void normalize(double denom) {
        if (!mceTraining) {
            assert(denom != 0.0);
            for (int i = 0; i < mean.coord.length; i++) {
                mean.coord[i] /= denom;
                cov.coord[i]= cov.coord[i]/denom - mean.coord[i] * mean.coord[i];
                if(cov.coord[i] < 1e-10) cov.coord[i] = 1e-10;
            }
            gconst = findGconst();
        } 
    }

    @Override
    protected void update(Gaussian delta) {
        GaussianDiag another = (GaussianDiag) delta;
        for (int i = 0; i < mean.coord.length; i++) {
            mean.coord[i] += another.mean.coord[i];
            //cov.coord[i] += another.cov.coord[i];
        }
        gconst = findGconst();
    }

    @Override
    protected void momentum(Gaussian another) {
        GaussianDiag prev = (GaussianDiag) another;
        for (int i = 0; i < mean.coord.length; i++) {
            if (mean.coord[i] * prev.mean.coord[i] > 0.0) {
                mean.coord[i] += prev.mean.coord[i];
            } else {
                mean.coord[i] = -prev.mean.coord[i] / 2.0; // back half
            }
            /*
            if (cov.coord[i] * prev.cov.coord[i] > 0.0) {
                cov.coord[i] += prev.cov.coord[i];
            } else {
                cov.coord[i] = -prev.cov.coord[i] / 2.0;
            }
            */
        }
        gconst = findGconst();
    }

    @Override
    public double bhattacharyyaDivergence(Gaussian gaussian) {
        if (!(gaussian instanceof GaussianDiag)) {
            return Double.NaN;
        }
        GaussianDiag another = (GaussianDiag) gaussian;
        double distance = 0.0;
        for (int i = 0; i < mean.coord.length; i++) {
            double diff = mean.coord[i] - another.mean.coord[i];
            distance += diff * diff / (cov.coord[i] + another.cov.coord[i]);
        }
        PointND middle = cov.plus(another.cov).scaling(0.5);
        distance += 2 * Math.log(middle.product());
        distance -= Math.log(cov.product() * another.cov.product());
        return 0.25 * distance;
    }
}
