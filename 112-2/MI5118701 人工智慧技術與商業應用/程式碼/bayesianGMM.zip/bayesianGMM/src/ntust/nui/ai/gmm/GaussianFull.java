
package ntust.nui.ai.gmm;

import ntust.nui.ai.common.PointND;
import ntust.nui.ai.common.Point;
import java.util.Collection;
import Jama.Matrix;


/**
 *
 * @author bslin
 */
public class GaussianFull extends Gaussian<GaussianFull.CovarianceFull> {
	public static double varLowerBound = 1e-4;

    private Matrix cov_inverse; // pre-calculated inverse covariance

    public static class CovarianceFull extends Matrix implements Gaussian.Covariance {

        private static final long serialVersionUID = 5;

        public CovarianceFull(int r, int c) {
            super(r, c);
        }

        private CovarianceFull(CovarianceFull prototype) {
            super(prototype.getRowDimension(), prototype.getColumnDimension());
            double a[][] = getArray();
            for(int i = 0; i < a.length; i++) {
                for(int j = 0; j < a[i].length; j++) {
                    a[i][j] = prototype.get(i, j);
                }
            }
        }

        @Override
        public Object clone() {
            return new CovarianceFull(this);
        }
        public String toString() {
            StringBuilder s = new StringBuilder();
            for(int i = 0; i < this.getColumnDimension(); i++) {
                if(i > 0) s.append(" ");
                s.append(this.get(i, i));
            }
            return s.toString();
        }

        @Override
        public void clear() {
            double a[][] = getArray();
            for (int i = 0; i < a.length; i++) {
                for (int j = 0; j < a[i].length; j++) {
                    a[i][j] = 0.0;
                }
            }
        }
        @Override
        public double average() {
            double sum = 0;
            double a[][] = getArray();
            for (int i = 0; i < a.length; i++) {
                    sum += a[i][i];
            }
            return sum / a.length;
        }

    }
    public GaussianFull() {
        super();
    }

    public GaussianFull(PointND m, CovarianceFull c) {
        super(m, c);
    }

    /**
     * �Hprototype����¦,���ͤ@�ӷs��Gaussian���G,�ƻs�Ҧ����.
     * @param prototype ��lGaussian�˥�.
     */
    protected GaussianFull(GaussianFull prototype) {
        super(prototype);
    }

    @Override
    public Object clone() {
        
        return new GaussianFull(this);
    }

    @Override
    public double getProbability(Point x) {
        return Math.exp(getLogProbability(x));
    }

    @Override
    protected double findGconst() {
        if (mean == null || cov == null) {
            System.err.println("mean/var not yet set!");
        }
        //System.out.println("cov=" + cov);
		try {
	        cov_inverse = cov.inverse();
			
		} catch (Exception e) {
			System.out.println("catch ex");
			e.printStackTrace();
			System.exit(1);
		}
        double sum = Math.log(2 * Math.PI) * mean.coord.length;
        sum += Math.log(Math.abs(cov.det()));
        return sum;
    }

    @Override
    protected void findMeanCov(Collection<Point> points) {
        for (Point point : points) {
            if (mean == null) {
                int dim = point.getCoordinates().length;
                mean = new PointND(dim);
                cov = new CovarianceFull(dim, dim);
            }
            double coord[] = point.getCoordinates();
            for (int i = 0; i < mean.coord.length; i++) {
                mean.coord[i] += coord[i];
            }
            double a[][] = cov.getArray();
            for (int i = 0; i < a.length; i++) {
                for (int j = 0; j < a[i].length; j++) {
                    a[i][j] += coord[i] * coord[j];
					if(a[i][j] < varLowerBound)a[i][j] = varLowerBound;
                }
            }
        }
        for (int i = 0; i < mean.coord.length; i++) {
            mean.coord[i] /= points.size();
        }
        double a[][] = cov.getArray();
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                a[i][j] /= points.size();
                a[i][j] -= mean.coord[i] * mean.coord[j];
            }
        }
        gconst = findGconst();
    }


    public double getLogProbability(Point x) {
        double sum = gconst;
        Matrix M = new Matrix(mean.coord.length, 1);
        for(int i = 0; i < mean.coord.length; i++) {
            M.set(i, 0, mean.coord[i]);
        }
        double coord[] = x.getCoordinates();
        //M.setColumn(mean.coord);
        Matrix X = new Matrix(coord.length, 1);
        for(int i = 0; i < coord.length; i++) {
            X.set(i, 0, coord[i]);
        }
        //X.setColumn(x.coord);
        Matrix D = X.minus(M);
        Matrix N = D.transpose().times(cov_inverse).times(D);
        sum += N.getArray()[0][0];
        return -0.5 * sum;
    }

    @Override
    protected void update(double likelihood, Point x, Gaussian old) {
        if (!mceTraining) {
            double coord[] = x.getCoordinates();
            for (int i = 0; i < mean.coord.length; i++) {
                mean.coord[i] += likelihood * coord[i];
            }
            double a[][] = cov.getArray();
            for (int i = 0; i < a.length; i++) {
                for (int j = 0; j < a[i].length; j++) {
                    a[i][j] += likelihood * coord[i] * coord[j];
                }
            }
        } else {
            // MCE training (Minimum Classification Errors) with GPD
            double coord[] = x.getCoordinates();
            for (int i = 0; i < mean.coord.length; i++) {
                double distance = (coord[i] - old.mean.coord[i]) / Math.sqrt(old.cov.get(i, i));
                double delta = epsilon * likelihood * distance;
                //if (withinCluster) { // within cluster --> same direction
                    mean.coord[i] += delta;
                    //for(int j = 0; j < cov.a[i].length; j++) {
                    //    cov.a[i][j] += epsilon * likelihood * (distance * distance - 1);
                    //}
                //} else { // different cluster --> opposite direction
                    //mean.coord[i] -= delta;
                    //for(int j = 0; j < cov.a[i].length; j++) {
                    //    cov.a[i][j] -= epsilon * likelihood * (distance * distance - 1);
                    //}
                //}
            }
        }
    }

    @Override
    protected void normalize(double denom) {
        if (!mceTraining) {
            for (int i = 0; i < mean.coord.length; i++) {
                mean.coord[i] /= denom;
            }
            double a[][] = cov.getArray();
            for (int i = 0; i < a.length; i++) {
                for (int j = 0; j < a[i].length; j++) {
                    a[i][j] /= denom;
                    a[i][j] -= mean.coord[i] * mean.coord[j];
                    if(a[i][j] < 1e-10) a[i][j] = 1e-10;
                }
            }
            gconst = findGconst();
        }
    }

    @Override
    protected void update(Gaussian delta) {

        GaussianFull another = (GaussianFull) delta;
        for (int i = 0; i < mean.coord.length; i++) {
            mean.coord[i] += another.mean.coord[i];
            /*
            double a[][] = cov.getArray(), a2[][] = another.cov.getArray();
            for (int j = 0; j < a[i].length; j++) {
                a[i][j] += a2[i][j];
            }
             */
        }
        gconst = findGconst();

    }

    @Override
    protected void momentum(Gaussian another) {
        GaussianFull prev = (GaussianFull) another;
        for (int i = 0; i < mean.coord.length; i++) {
            if (mean.coord[i] * prev.mean.coord[i] > 0.0) {
                mean.coord[i] += prev.mean.coord[i];
            } else {
                mean.coord[i] = -prev.mean.coord[i]/2.0;
            }
            /*
            for (int j = 0; j < cov.a[i].length; j++) {
                if (cov.a[i][j] * prev.cov.a[i][j] > 0.0) {
                    cov.a[i][j] += prev.cov.a[i][j];
                } else {
                    cov.a[i][j] /= 4.0;
                }
            }
             */
        }
    }

    public double bhattacharyyaDivergence(Gaussian gaussian) {
        if (!(gaussian instanceof GaussianFull)) {
            return Double.NaN;
        }
        GaussianDiag another = (GaussianDiag) gaussian;
        double distance = 0.0;
        /*
        for (int i = 0; i < mean.coord.length; i++) {
        double diff = mean.coord[i] - another.mean.coord[i];
        distance += diff * diff / (cov.coord[i] + another.cov.coord[i]);
        }
        Point middle = cov.plus(another.cov).scaling(0.5);
        distance += 2 * Math.log(middle.product());
        distance -= Math.log(cov.product() * another.cov.product());
        //System.out.println("distance=" + distance);
        return 0.25 * distance;
         */
        return distance;
    }
}
