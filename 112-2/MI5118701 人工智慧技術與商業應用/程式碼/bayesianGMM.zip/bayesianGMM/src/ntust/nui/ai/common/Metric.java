
package ntust.nui.ai.common;
/**
 * Metric is the metric defined for the type T which measures
 * the distance between this object and other object of type T.
 * @author Bor-Shen Lin at NTUST
 * @param <T>
 */
public interface Metric<T extends Metric> {
   double distance(T other);
}
