
package ntust.nui.ai.common;

import java.io.Serializable;


public interface Point extends Serializable, Cloneable {
//    int getDimension();
    double[] getCoordinates();    
}
