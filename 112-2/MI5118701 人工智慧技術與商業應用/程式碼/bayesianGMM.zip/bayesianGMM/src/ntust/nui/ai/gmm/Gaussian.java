
package ntust.nui.ai.gmm;

import ntust.nui.ai.common.PointND;
import ntust.nui.ai.common.Point;
import java.io.Serializable;
import java.util.Collection;

/**
 * @author bslin
 */
public abstract class Gaussian<T extends Gaussian.Covariance> implements Serializable, Cloneable {

    public interface Covariance {

        public abstract Object clone();

        public abstract void clear();

        public abstract double get(int row, int col);
        
        public abstract double det();
        
        public abstract double average();
    };
    static public boolean mceTraining = false;
    static public double epsilon = 0.00001;
    static private final long serialVersionUID = 2;

    PointND mean;
    T cov;
    double gconst;

    public Gaussian() {
        mean = null;
        cov = null;
        gconst = Double.NEGATIVE_INFINITY;
    }

    public Gaussian(PointND m, T c) {
        setData(m, c);
    }

    protected Gaussian(Gaussian prototype) {
        mean = (PointND) prototype.mean.clone();
        cov = (T) prototype.cov.clone();
    }

    public void setData(PointND m, T c) {
        mean = m;
        cov = c;
        gconst = findGconst();
    }

    public Point getMean() {
        return mean;
    }
    public T getCovariance() {
        return cov;
    }
    @Override
    public String toString() {
        return String.format("mean=%s,cov=%s", mean, cov);
    }

    public double getGconst() {
        return gconst;
    }

    public abstract double getProbability(Point x);

    public abstract double getLogProbability(Point x);

    @Override
    public abstract Object clone();

    protected abstract double findGconst();

    protected abstract void findMeanCov(Collection<Point> points);

    public void clear() {
        mean.clear();
        cov.clear();
    }

    protected Gaussian splitting(Collection<Point> points) {
//        PointND mean1 = (PointND) mean.clone(); //new Point(mean);
        PointND mean2 = (PointND) mean.clone(); //new Point(mean);
        Covariance cov2 = (Covariance) cov.clone(); //new Point(cov);
//        int count = 0;
//        for(Point point : points) {
//            double dist = -2*getLogProbability(point) - getGconst();
//            if(dist <= 4) count++;
//            for (int i = 0; i < mean.coord.length; i++) {
//                if(dist <= 4) mean2.coord[i] += point.getCoordinates()[i];
//                else mean1.coord[i] += point.getCoordinates()[i];
//            }                
//        }
//        for (int i = 0; i < mean.coord.length; i++) {
//            mean1.coord[i] /= points.size() - count;
//            mean2.coord[i] /= count;
//        }                
        double delta = 0.1;
        for (int i = 0; i < mean.coord.length; i++) {
            double stddev = Math.sqrt(cov.get(i, i));
            mean2.coord[i] += delta * stddev;
            mean.coord[i] -= delta * stddev;
            delta = -delta;
        }
        Gaussian newGaussian = (Gaussian) this.clone();
        newGaussian.setData(mean2, cov2);
//        this.setData(mean1, cov);
        return newGaussian;
    }

    protected void reset() {
        mean.clear();
        cov.clear();
    }

    protected abstract void update(double likelihood, Point x, Gaussian old);

    protected abstract void normalize(double denom);

    protected abstract void update(Gaussian delta);

    protected abstract void momentum(Gaussian newGaussian);

    public abstract double bhattacharyyaDivergence(Gaussian gaussian);
}
