package ntust.nui.ai.tool;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Iterator;

/**
 *
 * @author bslin
 * @param <T>
 */
public class LinesLoader<T> implements Iterable<T> {
    
    public interface Converter<T> {
        T convert(String line);
    }

    private class LineIterator implements Iterator<T> {

        BufferedReader reader;
        FileIterator iter1; // File
        Iterator<String> iter2; // String

        public LineIterator() {
            iter1 = (FileIterator) files.iterator();
        }

        void reset() {
            iter1.reset();
            try {
                if(reader != null) {
                    reader.close();
                    reader = null;
                }
                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public boolean hasNext() {
            try {
                while (true) {
                    if (reader == null) {
                        if (!iter1.hasNext()) {
                            return false;
                        }
                        File file = iter1.next();
                        reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
                        iter2 = reader.lines().iterator();
                    }
                    if (iter2.hasNext()) {
                        return true; // available
                    }
                    reader.close();
                    reader = null;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        public T next() {
            if(!hasNext()) return null;
            String line = iter2.next();
            return converter.convert(line);
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }
    private Files files;
    private LineIterator iterator;
    private final Converter<T> converter;

    public LinesLoader(File path, Converter<T> converter) throws FileNotFoundException{
        files = new Files(path);
        this.converter = converter;
    }

    @Override
    public Iterator<T> iterator() {
        if (iterator != null) {
            iterator.reset();
            return iterator;
        }
        return new LineIterator();
    }
}
