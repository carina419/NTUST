package ntust.nui.ai.knn;

import java.util.*;
import ntust.nui.ai.common.Kernel;

/**
 *
 * @author bslin
 * @param <P>
 */
public class KNN<P> {

    Kernel<P> kernel;
    Collection<P> data;
    Map<P, Double> map = new HashMap();
    Map<P, Double> pwf = new HashMap();

    public KNN(Collection<P> data, Kernel<P> kernel) {
        this.data = data;
        this.kernel = kernel;
    }
    public Map<P,Double> getPWF() {
        return pwf;
    }
    public double k(P ref) {
        double sum = 0;
        for (P point : data) {
            sum += kernel.similarity(point, ref);
        }
        sum /= data.size();
        pwf.put(ref, sum);
        return sum;
    }

    public double f(P ref, int K) {
        map.clear();
        for (P point : data) {
            map.put(point, kernel.similarity(ref, point));
        }
        List<double[]> sorted = new LinkedList(data);
        Collections.sort(sorted, (double[] a, double[] b) -> {
            double diff = map.get(b) - map.get(a);
            if (diff > 0) {
                return 1;
            } else if (diff < 0) {
                return -1;
            } else {
                return 0;
            }
        });

        double similarity = map.get(sorted.get(K - 1));
        double radius = -Math.log(similarity);
        double value = K / (Math.PI * radius * radius);
        value = Math.log(value);
        assert (!Double.isNaN(value));
        pwf.put(ref, value);
        return value;
    }
}
