package ntust.nui.ai.common;

/**
 * You can change the run() procedure, too.
 *
 * @author bslin
 * @param <T> The type of data point for applying the algorithm.
 */
public abstract class Algorithm<T> {

    public void run(Iterable<T> data) {
        initialize();
        data.forEach(this::iteration); // point->this.iteration(point)
        terminate();
    }

    public abstract void initialize();

    public abstract void iteration(T point);

    public abstract void terminate();

}
