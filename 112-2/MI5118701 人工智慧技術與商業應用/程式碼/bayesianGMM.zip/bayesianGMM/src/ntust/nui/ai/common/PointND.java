
package ntust.nui.ai.common;

import ntust.nui.ai.common.Point;
import java.util.Random;
import static ntust.nui.ai.common.PointND.getPoint;

/**
 *
 * @author bslin
 */
public class PointND implements Point, Metric<PointND> {
    private static final long serialVersionUID = 3;
    private static Random random = new Random(10);
    public double coord[];

    public PointND(int dim) {
        coord = new double[dim];
    }

    public PointND(double data[]) {
        coord = data;
    }
    
    protected PointND(PointND another) {
        coord = new double[another.coord.length];
        for (int i = 0; i < coord.length; i++) {
            coord[i] = another.coord[i];
        }
    }

//    public int getDimension() {
//        return coord.length;
//    }
    @Override
    public double[] getCoordinates() {
        return coord;
    }
    @Override
    public Object clone() {
        return new PointND(this);
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder("(");
        for (int i = 0; i < coord.length; i++) {
            if (i > 0) {
                s.append(", ");
            }
            s.append(String.format("%e", coord[i]));
        }
        return s.append(")").toString();

    }

    public void clear() {
        if (coord == null) {
            return;
        }
        for (int i = 0; i < coord.length; i++) {
            coord[i] = 0.0;
        }
    }

    public static PointND getPoint(int dim, double mean) {
        return getPoint(dim, mean, 1.0);
    }
    public static PointND getPoint(int dim, double mean, double dev) {
        PointND point = new PointND(dim);
        for (int i = 0; i < point.coord.length; i++) {
            point.coord[i] = mean + random.nextGaussian() * dev;
        }
        return point;
    }

    public boolean included(PointND points[]) {
        for (int k = 0; k < points.length; k++) {
            if (this == points[k]) {
                return true;
            }
        }
        return false;
    }

    public double innerProduct(PointND v2) {
        double sum = 0.0;
        for (int i = 0; i < coord.length; i++) {
            sum += coord[i] * v2.coord[i];
        }
        return sum;
    }

    public double norm() {
        double distance = 0.0;
        for (int i = 0; i < coord.length; i++) {
            distance += coord[i] * coord[i];
        }
        return Math.sqrt(distance);
    }

    public PointND plus(PointND another) {
        double data[] = new double[coord.length];
        for (int i = 0; i < data.length; i++) {
            data[i] = coord[i] + another.coord[i];
        }
        return new PointND(data);
    }

    public PointND minus(PointND another) {
        double data[] = new double[coord.length];
        for (int i = 0; i < data.length; i++) {
            data[i] = coord[i] - another.coord[i];
        }
        return new PointND(data);
    }

    public PointND scaling(double scale) {
        double data[] = new double[coord.length];
        for (int i = 0; i < coord.length; i++) {
            data[i] = coord[i] * scale;
        }
        return new PointND(data);
    }

    public PointND normal() {
        scaling(norm());
        return this;
    }


    public double distance(PointND another) {
        double sum = 0.0;
        for (int i = 0; i < coord.length; i++) {
            double diff = coord[i] - another.coord[i];
            sum += diff * diff;
        }
        return sum;
    }

    public double product() {
        double product = 1.0;
        for (int i = 0; i < coord.length; i++) {
            product *= coord[i];
        }
        return product;
    }

//    @Override
//    public double distance(PointND other) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    
}
