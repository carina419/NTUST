
package ntust.nui.ai.common;

/**
 * Classifier is defined for classification for data points of type T.
 * @author Bor-Shen Lin at NTUST
 * @param <T> The type of data points for applying classification algorithm.
 */
public interface Classifier<T> {
    int classify(T point);
}
