
package ntust.nui.ai.tool;

/**
 *
 * @author NUILAB
 */
import java.util.List;
import java.util.LinkedList;

public abstract class Filter<T> {
    public abstract boolean accept(T y);

    public List<T> process(T x[]) {
        List<T> list = new LinkedList();
        for (T y : x) {
            if (accept(y)) {
                list.add(y);
            }
        }
        return list;
    }
    public List<T> process(Iterable<T> x) {
        List<T> list = new LinkedList();
        for (T y : x) {
            if (accept(y)) {
                list.add(y);
            }
        }
        return list;
    }

    public static void main(String args[]) {
        Integer x[] = {12, 3, 45, 34, 78, 33, 89, 56};
        List<Integer> outputs = new Filter<Integer>() {

            public boolean accept(Integer x) {
                return (x % 2 == 1 && x >= 10 && x <= 60);
            }
        }.process(x);
        System.out.println(outputs);


        String fruits[] = {"grape", "potato", "apple", "orange", "melon", "banana", "pear", "guava", "peach"};
        Filter<String> filter2 = new Filter<String>() {

            public boolean accept(String x) {
                return x.startsWith("p");
            }
        };

        List<String> result = filter2.process(fruits);
        System.out.println(result);
        
    }
}
