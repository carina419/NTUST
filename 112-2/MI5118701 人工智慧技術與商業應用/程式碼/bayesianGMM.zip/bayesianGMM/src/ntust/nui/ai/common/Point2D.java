package ntust.nui.ai.common;






import java.util.*;

/**
 *
 * @author bslin
 */
public class Point2D implements Metric<Point2D> {

    private static Random random = new Random(5);
    public double x, y;

    public Point2D(double x1, double y1) {
        x = x1;
        y = y1;
    }

    public void set(double x, double y) {
        this.x = x;
        this.y = y;
    }
    
    @Override
    public String toString() {
        return String.format("(%.4f, %,4f)", x, y);
    }

    @Override
    public double distance(Point2D other) {
        double dx = x - other.x, dy = y - other.y;
        return dx * dx + dy * dy;
    }

    public static Point2D getRandomPoint() {
        double x = random.nextDouble() * 10;
        double y = random.nextDouble() * 10;
        return new Point2D(x, y);
    }
}
