
package ntust.nui.ai.common;

/**
 * Transform the document vector to eigen space.
 * @author bslin
 */
public interface Transformer {
    double[] transform(double d[]);
}
