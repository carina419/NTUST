package ntust.nui.ai.common;

/**
 * Kernel is the similarity measure defined for type P.
 * @author Bor-Shen Lin at NTUST
 * @param <P>
 */
public interface Kernel<P> {

    double similarity(P x, P y);
}
