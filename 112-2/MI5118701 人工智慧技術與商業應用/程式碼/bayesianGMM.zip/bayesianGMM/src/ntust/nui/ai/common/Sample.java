package ntust.nui.ai.common;



/**
 *
 * @author Bor-Shen Lin at NTUST
 */
public class Sample<I, O> {

    public I in;
    public O out;

    public Sample(I i, O o) {
        in = i;
        out = o;
    }
}
