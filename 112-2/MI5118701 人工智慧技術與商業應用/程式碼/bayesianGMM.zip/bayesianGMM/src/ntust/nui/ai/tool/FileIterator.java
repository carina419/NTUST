
package ntust.nui.ai.tool;
import java.io.File;
import java.util.Iterator;

/**
 *
 * @author borson
 */



public class FileIterator implements Iterator<File> {

    private File root;
    private File currentDir;
    private int currentIndex;
    private File current;
    private File next;

    public FileIterator(File path) {
        currentDir = root = path;
        currentIndex = 0;
    }

    public void reset() {
        currentDir = root;
        currentIndex = 0;
    }

    public File findNext() {
        if (!root.exists()) {
            return null;
        }
        if (root.isFile()) {
            return currentIndex == 0 ? root : null;
        }
        for (File files[] = currentDir.listFiles();;) {
            if (currentIndex < files.length) {
                if (files[currentIndex].isFile()) {
                    return files[currentIndex];
                }
                currentDir = files[currentIndex]; // enter sub dir
                files = currentDir.listFiles();
                currentIndex = 0;
                //System.out.println("enter sub " + currentDir);
                continue;
            }
            // current dir finished, go upwards
            if (currentDir.equals(root)) {
                return null;
            }
            File child = currentDir;
            currentDir = currentDir.getParentFile();
            files = currentDir.listFiles();
            //System.out.println("go upwards " + currentDir);
            for (int i = 0; i < files.length; i++) {
                //System.out.println("child=" + child + "\tfiles[i]=" + files[i]);
                if (files[i].equals(child)) {
                    currentIndex = i + 1;
                    //System.out.println("currentIndex=" + currentIndex);
                    break;
                }
            }
            //assert(files.length)
        }
    }

    @Override
    public boolean hasNext() {
        next = findNext();
        return next != null;
    }

    @Override
    public File next() {
        if (next != null) {
            current = next;
            currentIndex++;
        } else {
            current = findNext();
            if (current != null) {
                currentIndex++;
            }
        }
        next = null;
        return current;
    }

    @Override
    public void remove() {
        current.delete();
    }
}

