package ntust.nui.ai.common;

/**
 * The class Complex is for the representation of complex numbers.
 *
 * @author bslin
 */
public class Complex {

    public double real;
    public double imag;

    /**
     * Constructing a complex number containing zeros in real or imaginary part.
     */
    public Complex() {
        setData(0.0, 0.0);
    }

    /**
     * Constructing a complex number with assigned real and imaginary parts.
     *
     * @param r the value of the real part.
     * @param i the value of the imaginary part.
     */
    public Complex(double r, double i) {
        setData(r, i);
    }

    /**
     * Get the real part of the complex number.
     *
     * @return the real part.
     */
    public double getReal() {
        return real;
    }

    /**
     * Get the imaginary part of the complex number.
     *
     * @return the imaginary part.
     */
    public double getImag() {
        return imag;
    }

    public double getPhase() {
        return Math.atan2(imag, real);
    }
    public double getAmplitude() {
        return Math.sqrt(real * real + imag * imag);
    }
    /**
     * Set the complex number for given real and imaginary part.
     *
     * @param r the value of the real part.
     * @param i the value of the imaginary part.
     */
    public void setData(double r, double i) {
        real = r;
        imag = i;
    }

    /**
     * �ھڥt�@�ƼƳ]�w�t�Ƹ��
     *
     * @param c �t�@�Ƽ�
     */
    public void setData(Complex c) {
        real = c.real;
        imag = c.imag;
    }

    /**
     * �ܦ��@�m�Ƽ�
     */
    public void conjugate() {
        imag = -imag;
    }

    /**
     * ���ƼƻP�t�@�ƼƬۭ�,���G��N���Ƽ�
     *
     * @param c �t�@�Ƽ�
     */
    public void multiply(Complex c) {
        double r, i;
        r = real * c.real - imag * c.imag;
        i = real * c.imag + imag * c.real;
        real = r;
        imag = i;
    }

    /**
     * ���ƼƻP�t�@��Ƭۭ�,���G��N���Ƽ�
     *
     * @param f �t�@���
     */
    void multiply(float f) {
        real *= f;
        imag *= f;
    }

    /**
     * �p��Ƽƪ�power( = real * real + imag * imag)
     *
     * @return power
     */
    public double getPower() {
        return (real * real + imag * imag);
    }

    /**
     * �Ǧ^x+jy���������ƼƤ��e�y�z�r��
     *
     * @return �ƼƤ��e�y�z�r��
     */
    public String toString() {
        return real + "+" + imag + "j";
    }

    private static Complex getComplexWnk(int N, int k) {
        return new Complex(Math.cos(2. * Math.PI * k / (double) N), -Math.sin(2. * Math.PI * k / (double) N));
    }

    /**
     * �ֳt�ť߸�(Fast Fourier Transform,FFT)�t��k
     *
     * @param x ��J�ɰ�H��
     * @param y ��X�W��H��
     * @param N FFT��order(2, 4, 8,...)
     */
    public static void complexFFT(Complex x[], Complex y[], int N) {
        int i, k, N2 = N >> 1;
        Complex G[], H[], g[], h[], c;
        if (N == 1) {
            y[0].setData(x[0]);
            return;
        }
        g = new Complex[N2];
        h = new Complex[N2];
        G = new Complex[N2];
        H = new Complex[N2];
        for (i = 0; i < g.length; i++) {
            g[i] = new Complex();
            h[i] = new Complex();
            G[i] = new Complex();
            H[i] = new Complex();
        }
        for (i = 0; i < N2; i++) {
            g[i].setData(x[2 * i]);
            h[i].setData(x[2 * i + 1]);
        }
        complexFFT(g, G, N2);
        complexFFT(h, H, N2);
        for (k = 0; k < N2; k++) {
            c = getComplexWnk(N, k);
            c.multiply(H[k]);
            y[k].real = G[k].real + c.real;
            y[k].imag = G[k].imag + c.imag;
            y[k + N2].real = G[k].real - c.real;
            y[k + N2].imag = G[k].imag - c.imag;
        }
    }

    /**
     * �ϧֳt�ť߸�(Inverse Fast Fourier Transform,IFFT)�t��k
     *
     * @param x ��J�W��H��
     * @param y ��X�ɰ�H��
     * @param N IFFT��order(2, 4, 8,...)
     */
    public static void complexIFFT(Complex x[], Complex y[], int N) {
        float f = (float) 1. / (float) N;
        for (int i = 0; i < N; i++) {
            x[i].conjugate();
        }
        complexFFT(x, y, N);
        for (int i = 0; i < N; i++) {
            y[i].multiply(f);
            y[i].conjugate();
        }
    }
}
