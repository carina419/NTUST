package ntust.nui.ai.gmm;

import ntust.nui.ai.common.PointND;
import ntust.nui.ai.common.Point;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import java.util.Set;

/**
 * This class demonstrates the EM algorithm for GMM training.
 *
 * @author bslin
 */
public class GMM implements Serializable {

	private static final long serialVersionUID = 1;
	public static int debugCount = 10;
	public static double averageOutput;

	private static double alpha = 30;
	private static GMM prevDeltaGMMs[];

	private List<Double> weights;
	private List<Gaussian> gaussians;
	private double likelihoods[];
	private double discrimination;
	private double ratio;

	/**
	 * Constructor of GMM object.
	 */
	public GMM() {
		weights = new LinkedList();
		gaussians = new LinkedList();
	}

	/**
	 * Construct a new GMM object using the parameters of a prototype GMM.
	 *
	 * @param prototype a prototype of GMM
	 */
	public GMM(GMM prototype) {
		this();
		for (Gaussian gauss : prototype.gaussians) {
			gaussians.add((Gaussian) gauss.clone());
		}
		for (Double weight : prototype.weights) {
			weights.add((Double) new Double(weight.doubleValue()));
		}
	}

	/**
	 * Get a list of Gaussian distributions.
	 *
	 * @return
	 */
	public List<Gaussian> getGaussians() {
		return gaussians;
	}

	/**
	 * Display the detailed information for this GMM object.
	 *
	 * @return the formated string containing the information of GMM.
	 */
	@Override
	public String toString() {
		return "weights:" + weights.toString() + "\ngaussians:" + gaussians;
	}

	/**
	 * Get the logrithm of the probability density for a sample. Log-add is
	 * utilized to avoid overflow.
	 *
	 * @param point the sample point
	 * @return the logarithm of the probability density
	 */
	public double getLogProbability(Point point) {
		double sum = 0;
		for (int i = 0; i < gaussians.size(); i++) {
			Gaussian gaussian = gaussians.get(i);
//            double prob = gaussian.getProbability(point);
//            sum += weights.get(iter) * prob;
			assert (weights.get(i) != null && gaussian != null);
			double a = Math.log(weights.get(i)) + gaussian.getLogProbability(point);
			if (i == 0) {
				sum += a;
			} else {
				if (sum > a) {
					sum += Math.log(1 + Math.exp(a - sum));
				} else {
					sum = a + Math.log(1 + Math.exp(sum - a));
				}
			}
		}
		return sum;
	}

	/**
	 * Get the probability density for a sample.
	 *
	 * @param point the sample point
	 * @return the probability density
	 */
	public double getProbability(Point point) {
		double sum = 0;
		for (int i = 0; i < gaussians.size(); i++) {
			Gaussian gaussian = gaussians.get(i);
			double prob = gaussian.getProbability(point);
			sum += weights.get(i) * prob;
		}
		return sum;
	}

	/**
	 * Train the GMM using a Gaussian distribution (full/diagonal) as template.
	 *
	 * @param gaussian A template Gaussian indicating full/diagonal covariance
	 * matrix
	 * @param points all training samples
	 * @param mixtureNum the number of mixtures of the GMM
	 * @param iterationNum the number of iteration for every mixture after
	 * splitting
	 * @return the GMM
	 */
	public void train(Gaussian gaussian, Collection<Point> points, int mixtureNum, int iterationNum) {
		Gaussian.mceTraining = false;
		//System.out.println("points size "+points.size());
		//System.out.flush();
		gaussian.findMeanCov(points);
		gaussians.add(gaussian);
		weights.add(1.0);
//        double sum = this.findExpect(points);
		//System.out.println(this.weights.size() + "\t" + sum);
		while (gaussians.size() < mixtureNum) {
			split(points);
			iteration(points, iterationNum);
//            sum = this.findExpect(points);
			//System.out.println(this);
//            System.out.println(this.weights.size() + "\t" + sum);
		}
	}

	/**
	 * Comppute the average of Bhattacharyya divergence between two GMMs.
	 *
	 * @param other the other GMM to be compared with this GMM
	 * @return the averagae distance
	 */
	public double distance(GMM other) {
		double distance = 0.0;
		for (double weight : weights) {
			double average = 0.0;
			Gaussian gaussian = gaussians.get(weights.indexOf(weight));
			for (double weight2 : other.weights) {
				int index = other.weights.indexOf(weight2);
				average += weight2 * gaussian.bhattacharyyaDivergence(other.gaussians.get(index));
			}
			average /= other.weights.size();
			distance += weight * average;
		}
		return distance / weights.size();
	}

	/**
	 * Select the mixture of Gaussian with maximum variance from this GMM to
	 * split.
	 *
	 * @param points the training samples
	 */
	private void split(Collection<Point> points) {
//        Gaussian argmax = findMaxCovGaussian();
		Gaussian argmax = gaussians.get(findMaxWeightIndex());
		Gaussian newGaussian = argmax.splitting(points);
		int index = gaussians.indexOf(argmax);
		double weight = weights.get(index) / 2;
		weights.remove(index);
		weights.add(index, weight); // update weight for argmax
		gaussians.add(newGaussian);
		weights.add(weight);
	}

	/**
	 * Compute the expectation of log probability of this GMM for all the
	 * training samples.
	 *
	 * @param points the training samples
	 * @return the expectation of log probability
	 */
	public double findExpect(Collection<Point> points) {
		double logProb = 0;
		for (Point point : points) {
			logProb += getLogProbability(point);
		}
		return logProb / points.size();
	}

	/**
	 * Compute average log probabilities for the training samples.
	 *
	 * @param points the training samples
	 * @return the sum
	 */
	public double findExpectation(Collection<Point> points) {
		double sum = 0;
		for (Point point : points) {
			sum = getLogProbability(point);
		}
		return sum / points.size();
	}

	private void iteration(Collection<Point> points, int maxIterNum) {
		double prev = -1;
		for (int iter = 0; ++iter < maxIterNum;) {
			GMM next = this.reestimateEM(points);
			this.gaussians = next.gaussians;
			this.weights = next.weights;
			double objective = this.findExpectation(points);
			if (iter % debugCount == 0) {
				System.out.println("# mix=" + weights.size() + "\titer=" + iter + "\t" + objective);
			}
			if (Math.abs((objective - prev) / objective) < 1e-10) {
				break;
			}
			prev = objective;
		}
	}

	static private double sigmoid(double x) {
		return 1.0 / (1.0 + Math.exp(-alpha * x));
	}

	static private double getDistance(GMM gmms[], Point point, GMM currentGMM) {
		double sum = 0;
		for (int i = 0; i < gmms.length; i++) {
			GMM gmm = gmms[i];
			gmm.findLikelihood(point);

			if (gmm != currentGMM) {
				gmm.ratio = Math.exp(gmm.discrimination);
				sum += gmm.ratio;
			}
		}
		for (int i = 0; i < gmms.length; i++) {
			gmms[i].ratio /= sum;
		}
		return currentGMM.discrimination - Math.log(sum / (gmms.length - 1));
	}

	static private int findMaxProbability(Point point, GMM gmms[]) {
		int argmax = -1;
		double max = -Double.MAX_VALUE;
		for (int i = 0; i < gmms.length; i++) {
			double value = gmms[i].getProbability(point);
			if (argmax == -1 || value > max) {
				max = value;
				argmax = i;
			}

		}
		return argmax;
	}

	private static void mceTraining(GMM gmms[], Set<Point> data[]) {
		GMM deltas[] = new GMM[gmms.length];
		for (int i = 0; i < gmms.length; i++) {
			deltas[i] = new GMM(gmms[i]);
			for (Gaussian gaussian : deltas[i].gaussians) {
				gaussian.clear();
			}
		}
		int total = 0;
		for (int k = 0; k < data.length; k++) {
			total += data[k].size();
		}
		averageOutput = 0.0;
		for (int k = 0; k < data.length; k++) {
			GMM currentGMM = gmms[k];
			for (Point point : data[k]) {
				double distance = getDistance(gmms, point, currentGMM);
				double output = sigmoid(distance);
				double scaling = output * (1.0 - output);
				for (GMM gmm : gmms) {
					for (int m = 0; m < gmm.likelihoods.length; m++) {
						gmm.likelihoods[m] *= scaling;
						if (gmm != currentGMM) {
							gmm.likelihoods[m] *= -gmm.ratio;
						}
					}
				}
				for (int i = 0; i < gmms.length; i++) {
					deltas[i].update(point, gmms[i]);
				}
				averageOutput += output;
			}
		}
		averageOutput /= total;
		for (int i = 0; i < deltas.length; i++) {
			for (int m = 0; m < deltas[i].gaussians.size(); m++) {
				// momentum for model update
				if (prevDeltaGMMs != null) {
					deltas[i].gaussians.get(m).momentum(prevDeltaGMMs[i].gaussians.get(m));
				}
				gmms[i].gaussians.get(m).update(deltas[i].gaussians.get(m));
			}
		}
		prevDeltaGMMs = deltas;
	}

	public static void reestimateMCE(GMM gmms[], Set<Point> data[], int maxIterNum) {
		System.out.println("MCE training......");
		Gaussian.mceTraining = true;
		double prev = 0.0;
		for (int iter = 0; iter < maxIterNum; iter++) {
			GMM.mceTraining(gmms, data);
			double diff = (prev > 0.0) ? GMM.averageOutput - prev : 0.0;
			System.out.println(iter + "\t" + GMM.averageOutput + "\t" + diff);
			prev = GMM.averageOutput;
		}
		Gaussian.mceTraining = false;
	}

	private GMM reestimateEM(Collection<Point> points) {
		GMM newGMM = new GMM(this);
		for (int m = 0; m < newGMM.gaussians.size(); m++) {
			newGMM.gaussians.get(m).reset();
			newGMM.weights.clear();
		}
		double[] sumLikelihoods = new double[gaussians.size()];
		for (Point point : points) {
			this.findLikelihood(point);
			for (int m = 0; m < likelihoods.length; m++) {
				sumLikelihoods[m] += this.likelihoods[m];
			}
			newGMM.update(point, this);
		}
		double sumAll = 0.0;
		for (int m = 0; m < sumLikelihoods.length; m++) {
			sumAll += sumLikelihoods[m];
		}
		// normalization
		for (int m = 0; m < sumLikelihoods.length; m++) {
			if (sumLikelihoods[m] == 0.0) {
				for (int i = 0; i < sumLikelihoods.length; i++) {
					System.err.println(i + "\t" + sumLikelihoods[i]);
				}
			}
			assert (sumLikelihoods[m] != 0.0);
			newGMM.gaussians.get(m).normalize(sumLikelihoods[m]);
			newGMM.weights.add(sumLikelihoods[m] / sumAll);
		}
		return newGMM;
	}

	private void update(Point point, GMM old) {
		for (int m = 0; m < gaussians.size(); m++) {
			gaussians.get(m).update(old.likelihoods[m], point, old.gaussians.get(m));
		}
	}

	public double[] findLikelihood(Point point) {
		likelihoods = new double[gaussians.size()];
		double sum = 0.0;
		for (Gaussian gaussian : gaussians) {
			int index = gaussians.indexOf(gaussian);
			likelihoods[index] = weights.get(index) * gaussian.getProbability(point);
			assert (!Double.isNaN(likelihoods[index]));
			assert (!Double.isInfinite(likelihoods[index]));
			sum += likelihoods[index];
		}
		if (sum > 0) {
			for (int i = 0; i < likelihoods.length; i++) {
				likelihoods[i] /= sum;
			}
			discrimination = Math.log(sum);
		}
		else discrimination = 0;
		return likelihoods;
	}

	// findLikelihood2() might be necesary to replace findLikelihood in case  
	// overflow/underflow occur in the computation of probability 
	public double[] findLikelihood2(Point point) {
		likelihoods = new double[gaussians.size()];
		double max = -Double.MAX_VALUE;
		for (Gaussian gaussian : gaussians) {
			int index = gaussians.indexOf(gaussian);
			likelihoods[index] = Math.log(weights.get(index)) + gaussian.getLogProbability(point);
			if (likelihoods[index] > max) {
				max = likelihoods[index];
			}
		}
		double sum = 0.0;
		for (Gaussian gaussian : gaussians) {
			int index = gaussians.indexOf(gaussian);
			likelihoods[index] = Math.exp(likelihoods[index] - max);
			assert (!Double.isNaN(likelihoods[index]));
			assert (!Double.isInfinite(likelihoods[index]));
			sum += likelihoods[index];
		}
		assert (sum != 0);
		for (int i = 0; i < likelihoods.length; i++) {
			likelihoods[i] /= sum;
		}
		discrimination = Math.log(sum)+max;
		return likelihoods;
	}

	private Gaussian findMaxCovGaussian() {
		Gaussian argmax = null;
		double max = -Double.MAX_VALUE;
		for (Gaussian gaussian : gaussians) {
			double var = 0;
			int dim = gaussian.mean.getCoordinates().length;
			for (int i = 0; i < dim; i++) {
				var += gaussian.cov.get(i, i);
			}
			if (var > max) {
				max = var;
				argmax = gaussian;
			}

		}
		assert (argmax != null);
		return argmax;
	}

	private int findMaxWeightIndex() {
		Double argmax = null;
		for (Double weight : weights) {
			if (argmax == null || weight.doubleValue() > argmax.doubleValue()) {
				argmax = weight;
			}

		}
		assert (argmax != null);
		return weights.indexOf(argmax);
	}

	static public int findMaxWithThreshold(Point point, GMM gmms[], double threshold) {
		if (gmms.length != 2) {
			return -1;
		}
		assert (!Double.isNaN(gmms[0].getProbability(point)));
		assert (!Double.isNaN(gmms[1].getProbability(point)));
		//if(Double.isNaN(gmms[0].getProbability(point))) return 1;
		//if(Double.isNaN(gmms[1].getProbability(point))) return 0;
		double p1 = Math.log(gmms[1].getProbability(point));
		double p0 = Math.log(gmms[0].getProbability(point));
		//System.out.println("p1="+p1+"p0="+p0);
		return p1 - p0 > threshold ? 1 : 0;
	}

	static public void ev(Set<Point> dataSet[], GMM gmms[]) {
		double max = -1000;
		double argmax = 0;
		for (double threshold = -3; threshold <= 1.0; threshold += 0.1) {
			double N00 = 0, N11 = 0, N10 = 0, N01 = 0;
			for (Point point : dataSet[1]) { // labeld as 1
				int decisionClass = findMaxWithThreshold(point, gmms, threshold);
				if (decisionClass == 0) {
					N10++;
				} else {
					N11++;
				}
			}
			for (Point point : dataSet[0]) { // labeld as 0
				int decisionClass = findMaxWithThreshold(point, gmms, threshold);
				if (decisionClass == 0) {
					N00++;
				} else {
					N01++;
				}
			}
			double precision = N11 / (double) (N11 + N01);
			double recall = N11 / (double) (N11 + N10);
			double fmeasure = 2 * precision * recall / (precision + recall);
			//System.out.println(threshold + "\t" + precision + "\t" + recall + "\t" + fmeasure);
			if (fmeasure > max) {
				max = fmeasure;
				argmax = threshold;
			}
		}
		System.out.println("max = " + max + " argmax=" + argmax);
	}

	static public Set[] loadSamples(String filename) {
		Set data[] = {new HashSet<Point>(), new HashSet<Point>()};
		String text;
		try {
			BufferedReader input = new BufferedReader(new FileReader(filename));
			while ((text = input.readLine()) != null) {
				int index = text.indexOf(" ");
				//System.out.println("index =>"+index);
				String keyword = text.substring(0, index);
				//System.out.println(keyword);
				text = text.substring(index + 1, text.length());
				//System.out.println(text);
				String[] tokens = text.split(" ");
				//System.out.println(tokens.length);
				double[] indata = new double[4];
				double[] outdata = new double[1];
				// ��Jsample.in/sample.out

				//indata[0] = Double.valueOf(tokens[0]) ;  //count
				indata[0] = Double.valueOf(tokens[1]);  //DLG
				//indata[1] = Double.valueOf(tokens[2]);  //LogC
				indata[1] = Double.valueOf(tokens[3]);//AV
				indata[2] = Double.valueOf(tokens[4]);  //Link
				//indata[4] = Double.valueOf(tokens[5]); //Weakest
				//indata[3] = Double.valueOf(tokens[6]); //OutLink (AVWord, Boundry)
				indata[3] = Double.valueOf(tokens[6]); //First Char feature (AVWord, Boundry)
				//indata[3] = Double.valueOf(tokens[8]); //Last Char feature

				outdata[0] = Double.valueOf(tokens[8]).intValue() == 0 ? 0.0 : 1.0; //ans

				if (outdata[0] == 0.0) {
					data[0].add(new PointND(indata));
				} else {
					data[1].add(new PointND(indata));
				}

				//StringBuffer temp = this.normalization(keyword, totalindata);
			}
			//���W�ƼƭȡA��X�ɮ�
			//  this.normalization(anavalue);

			return data;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}

	}

	static public void evaluate(GMM gmms[], Set<Point> dataSet[]) {
		int accurateNum = 0;
		int total = 0;
		for (int i = 0; i < dataSet.length; i++) {
			for (Point point : dataSet[i]) {
				int argmax = findMaxProbability(point, gmms);
				if (argmax == i) {
					accurateNum++;
				}
			}
			total += dataSet[i].size();
		}
		System.out.println("acc=" + accurateNum + "(" + total + ")");
	}

	/**
	 * Find maximum likelihood cluster. It is used when GMM is used for
	 * clustering task.
	 *
	 * @param point
	 * @return
	 */
	public int findMLCluster(Point point) {
		double l[] = findLikelihood(point);
		double max = -Double.MAX_VALUE;
		int argmax = -1;
		for (int m = 0; m < l.length; m++) {
			if (l[m] > max) {
				max = l[m];
				argmax = m;
			}
		}
		return argmax;
	}

	public List<Point>[] distributePoints(Collection<Point> data) {
		List<Point> clusters[] = new LinkedList[gaussians.size()];
		for (int m = 0; m < clusters.length; m++) {
			clusters[m] = new LinkedList();
		}
		for (Point point : data) {
			int argmax = findMLCluster(point);
			assert (argmax >= 0 && argmax < gaussians.size());
			clusters[argmax].add(point);
		}
		for (int i = 0; i < clusters.length; i++) {
			sortCluster(clusters[i], gaussians.get(i));
		}
		return clusters;
	}

	private void sortCluster(List<Point> cluster, Gaussian gaussian) {
		double c[] = null;
		for (Point point : cluster) {
			if (c == null) {
				c = new double[point.getCoordinates().length];
			}
			for (int i = 0; i < c.length; i++) {
				c[i] += point.getCoordinates()[i];
			}
		}
		for (int i = 0; i < c.length; i++) {
			c[i] /= cluster.size();
		}
		final Map<Point, Double> map = new HashMap();
		for (Point point : cluster) {
			double dist = 0;
			for (int i = 0; i < c.length; i++) {
				double diff = c[i] - point.getCoordinates()[i];
				dist += diff * diff;
			}
			map.put(point, dist);
//            map.put(point, gaussian.getProbability(point));
		}
		cluster.sort(new Comparator<Point>() {
			@Override
			public int compare(Point a, Point b) {
				double diff = map.get(a) - map.get(b);
				return diff < 0 ? -1 : diff > 0 ? 1 : 0;
			}
		});
	}
}
