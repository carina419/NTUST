package ntust.nui.ai.bn;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.List;
import ntust.nui.ai.common.Classifier;
import ntust.nui.ai.tool.LinesLoader;
/**
 * NaiveBayes demonstrates the Bayesian classifer.
 * 
 * @author Bor-Shen Lin at National Taiwan University of Science and Technology
 * ****************************************************************************
 * Corinthians 13:4-7 Love is patient, love is kind. It does not envy, 
 * it does not boast, it is not proud.
 * 
 */
public class NaiveBayes implements Classifier<String[]>{

    int outputField; // the output field (class label) for the data table
    List<String[]> data;
    List<String>[] valueLists;
    double p[][][]; // p[i][xi][y] --> P(y|xi)

    public NaiveBayes(File trainingFile, String delimiter, int outputField) throws FileNotFoundException {
        this.outputField = outputField;
        System.out.println("trainingFile=" + trainingFile);
        Iterable<String[]> table = new LinesLoader(trainingFile, (String line) -> {
            System.out.println(line);
            return line.split(delimiter);
        });
        data = new LinkedList();
        for (String[] fields : table) {
            data.add(fields);
        }

        String titles[] = data.remove(0);
        valueLists = new LinkedList[titles.length];
        for (int i = 0; i < valueLists.length; i++) {
            valueLists[i] = new LinkedList();
        }
        for (String[] fields : data) {
            for (int i = 0; i < fields.length; i++) {
                if(!valueLists[i].contains(fields[i])) {
                    valueLists[i].add(fields[i]);
                }
            }
        }

        p = new double[titles.length][][];
        for (int i = 0; i < p.length; i++) {
            p[i] = new double[valueLists[i].size()][valueLists[outputField].size()];
        }
        for (String[] fields : data) {
            for (int i = 0; i < fields.length; i++) {
                if (i == outputField) {
                    continue; // ignore outputField
                }
                int xi = valueLists[i].indexOf(fields[i]);
                int y = valueLists[outputField].indexOf(fields[outputField]);
                p[i][xi][y] += 1;
            }
        }
        for (int i = 0; i < p.length; i++) {
            for (int x = 0; x < p[i].length; x++) {
                double denom = 0;
                for (int y = 0; y < p[i][x].length; y++) {
                    denom += p[i][x][y];
                }
                for (int y = 0; y < p[i][x].length; y++) {
                    p[i][x][y] /= denom;
                }
            }
        }
    }

    public List<String[]> getData() {
        return data;
    }
    
    public List<String> getValueList(int i) {
        assert(i >= 0 && i < valueLists.length);
        return valueLists[i];
    }
    
    @Override
    public int classify(String fields[]) {
        int argmax = -1;
        double max = -Double.MAX_VALUE;
        for(int y = 0; y < valueLists[outputField].size(); y++) {
            double prob = 1; // p(y|X) 
            for(int i = 0; i < fields.length; i++) {
                if(i == outputField) continue;
                int x = valueLists[i].indexOf(fields[i]);
                prob *= p[i][x][y];
            }
            if(prob > max) {
                max = prob;
                argmax = y;
            }
        }
        return argmax;
    }

}
