
import java.io.File;
import java.io.FileNotFoundException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import ntust.nui.ai.bn.NaiveBayes;
/**
 * This sample demonstrates the  task of risk classification using 
 * naive Bayesian classifier.
 * 
 * @author Bor-Shen Lin at National Taiwan University of Science and Technology
 * ****************************************************************************
 * Corinthians 13:4-7 Love is patient, love is kind. It does not envy, 
 * it does not boast, it is not proud.
 */
public class NaiveBayesTest {

     String tableFileName = "memberData.csv";
     String delimiter = ",";
     int outputField = 0;

    public static void main(String args[]) throws CloneNotSupportedException, URISyntaxException, FileNotFoundException {
            new NaiveBayesTest().exec();
    }

    private void exec() throws 
            CloneNotSupportedException, URISyntaxException, FileNotFoundException {

        URL url = getClass().getClassLoader().getResource(tableFileName);
        File trainingFile = new File(url.toURI());
        NaiveBayes classifier = new NaiveBayes(trainingFile, delimiter, outputField);
        
        System.out.println("\n------- inside test ---------");
        List<String> outputList = classifier.getValueList(outputField);
        for (String fields[] : classifier.getData()) {
            int y = classifier.classify(fields);
            System.out.println(Arrays.asList(fields) + " --> " + outputList.get(y));
        }
        System.out.println("\n------- outside test ---------");
        
        String test[] = new String[]{null, "unknown", "low", "adequate", "15k-35k"};
        int y = classifier.classify(test);
        System.out.println(Arrays.asList(test) + " --> " + outputList.get(y));
    }
}
