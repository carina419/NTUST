
import ntust.nui.ai.common.Point;
import java.util.HashSet;
import java.util.Set;
import ntust.nui.ai.gmm.GMM;
import static ntust.nui.ai.gmm.GMM.ev;
import static ntust.nui.ai.gmm.GMM.evaluate;
import static ntust.nui.ai.gmm.GMM.loadSamples;
import ntust.nui.ai.gmm.GaussianDiag;
import ntust.nui.ai.common.PointND;
import ntust.nui.ai.gmm.GaussianFull;

/**
 *
 * @author bslin
 */
public class GMMTest {
    static public void main(String args[]) {
        test3();
    }

    static public void test1() {
        Set<Point> data = new HashSet();
        for (int i = 0; i < 2000; i++) {
            data.add(PointND.getPoint(2, 0));
        }
        for (int i = 0; i < 2000; i++) {
            data.add(PointND.getPoint(2, 5));
        }
        for (int i = 0; i < 2000; i++) {
            data.add(PointND.getPoint(2, 10));
        }

        System.out.println(data);
        GMM gmm = new GMM();
        gmm.train(new GaussianDiag(), data, 6, 100);
        System.out.println(gmm);
    }

    static public void test2() {
        int trainingNum = 1000;
        Set data[] = {new HashSet(), new HashSet()};
        for (int i = 0; i < trainingNum; i++) {
            data[0].add(PointND.getPoint(2, 0.0));
            data[1].add(PointND.getPoint(2, 1.0));
        }
        
        GMM gmms[] = {new GMM(), new GMM()};
        for (int i = 0; i < gmms.length; i++) {
            //gmms[i].train(new GaussianFull(), data[i], 5, 50);
            gmms[i].train(new GaussianDiag(), data[i], 5, 50);
            System.out.println(gmms[i]);
        }
        //inside test
        evaluate(gmms, data);
    }

    static public void test3() {
        int trainingNum = 1000;
        Set data[] = {new HashSet(), new HashSet()};
        for (int i = 0; i < trainingNum; i++) {
            data[0].add(PointND.getPoint(2, 0.0));
            data[1].add(PointND.getPoint(2, 1.0));
        }
        // EM training
        GMM gmms[] = {new GMM(), new GMM()};
        for (int i = 0; i < gmms.length; i++) {
            gmms[i].train(new GaussianDiag(), data[i], 1, 50);
            System.out.println(gmms[i]);
        }
        evaluate(gmms, data);
        GMM.reestimateMCE(gmms, data, 10000);
        evaluate(gmms, data);
    }
    
}
