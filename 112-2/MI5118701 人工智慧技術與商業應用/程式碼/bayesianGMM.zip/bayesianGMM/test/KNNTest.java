
import java.awt.Color;
import java.awt.Graphics;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import javax.swing.JFrame;
import javax.swing.JPanel;
import ntust.nui.ai.knn.GaussianKernel;
import ntust.nui.ai.knn.KNN;


/**
 *
 * @author borson
 */
public class KNNTest {

    int centerX = 200, centerY = 200;
    Set<double[]> data;
    KNN<double[]> knn;

    class MyPanel extends JPanel {

        @Override
        public void paintComponent(Graphics g) {
            double min = 1e20;
            double max = -1e20;
            for (int i = -150; i < 150; i++) {
                for (int j = -150; j < 150; j++) {
                    double x = centerX + i, y = centerY + j;
                    double point[] = new double[]{x, y};
                    double density = knn.f(point, 3); // KNN
//                    double density = knn.k(point); //kernel
                    if (density > max) {
                        max = density;
                    }
                    if (density < min) {
                        min = density;
                    }
                }
            }
            Map<double[], Double> pwf = knn.getPWF();
            double range = max - min;
            for (double[] point : pwf.keySet()) {
                float value = (float) ((pwf.get(point) - min) / range); // 0 - 1
                if (value < 0.0) {
                    value = 0f;
                }
                assert (value >= 0 && value <= 1);
                Color color = new Color((float) value, (float) (1 - value), (float) (1 - value));
                g.setColor(color);
                g.fillOval((int) point[0], (int) point[1], 2, 2);
            }
            g.setColor(Color.ORANGE);
            data.stream().forEach((point) -> {
                g.fillOval((int) point[0], (int) point[1], 4, 4);
            });
        }
    }

    public static void main(String args[]) {
        new KNNTest().exec();
    }
    private void exec() {
        data = createData(20);
        GaussianKernel kernel = new GaussianKernel(10);
        knn = new KNN(data, kernel);

        JFrame frame = new JFrame("KNN");
        frame.add(new MyPanel());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(640, 480);
        frame.setVisible(true);
    }

    public Set<double[]> createData(int num) {
        Set<double[]> data = new HashSet();
        Random random = new Random(100);
        for (int i = 0; i < num; i++) {
            double point[] = new double[2];
            point[0] = random.nextGaussian() * 50 + centerX;
            point[1] = random.nextGaussian() * 50 + centerY;
            data.add(point);
        }
        return data;
    }

}
