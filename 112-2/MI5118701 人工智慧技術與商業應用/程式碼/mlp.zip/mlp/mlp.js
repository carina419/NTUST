"use strict";
/*
This program is for demonstrating the concept of multi-layer perceptrons.
Two examples are given: one is the parity check task and the other is the iris
classification task.

Author: Bor-Shen Lin at National Taiwan University of Science and Technology
*****************************************************************************
Genesis 1:1 In the beginning God created the heavens and the earth.
*/
Object.defineProperty(exports, "__esModule", { value: true });
exports.MLP = exports.Neuron = exports.Samples = exports.Sample = exports.mlp = void 0;
var mlp;
(function (mlp) {
    mlp.eps = 0.1;
    mlp.epsDefault = 0.1;
    mlp.debug = true;
    mlp.debugCount = 10;
    mlp.momentum = true;
})(mlp || (exports.mlp = mlp = {}));
class Sample {
    constructor(input, output) {
        this.input = input;
        this.output = output;
    }
}
exports.Sample = Sample;
class Samples {
    constructor(samples) {
        this.samples = samples;
    }
    getNumSamples() { return this.samples.length; }
    getSample(i) {
        return this.samples[i];
    }
}
exports.Samples = Samples;
class Sigmoid {
    get(x) {
        return 1 / (1 + Math.exp(-x));
    }
    derivative(y) {
        return y * (1.0 - y); // only for sigmoid: f'(x) = f(x)*(1-f(x))
    }
}
class Kernel {
    constructor(numInputs) {
        this.w = new Array(numInputs);
        this._w = new Array(numInputs);
        this.__w = new Array(numInputs);
        for (var i = 0; i < this.w.length; i++) {
            this.w[i] = (Math.random() - 0.5) * 2; // (-1,1)
            this._w[i] = 0;
            this.__w[i] = 0;
        }
        this.b = (Math.random() - 0.5) * 2;
        this._b = 0;
        this.__b = 0;
        this.activation = new Sigmoid();
    }
    similarity(inputs) {
        var sum = this.b;
        for (var i = 0; i < inputs.length; i++) {
            sum += this.w[i] * inputs[i].output;
        }
        return this.activation.get(sum);
    }
    derivative(inputs) {
        var y = this.similarity(inputs);
        return this.activation.derivative(y);
    }
    propagate(index, grad) {
        return this.w[index] * grad;
    }
    learn(inputs, grad) {
        for (var i = 0; i < this._w.length; i++) {
            this._w[i] += grad * inputs[i].output;
        }
        this._b += grad;
    }
    update() {
        for (var i = 0; i < this.w.length; i++) {
            if (mlp.momentum && this._w[i] * this.__w[i] > 0.0) {
                this._w[i] += this.__w[i];
            }
            this.w[i] += mlp.eps * this._w[i];
        }
        if (mlp.momentum && this._b * this.__b > 0.0) {
            this._b += this.__b;
        }
        this.b += mlp.eps * this._b;
        for (var i = 0; i < this._w.length; i++) {
            this.__w[i] = this._w[i];
            this._w[i] = 0.0;
        }
        this.__b = this._b;
        this._b = 0.0;
    }
}
class Neuron {
    constructor(numInputs) {
        this.inputs = new Array(numInputs);
        this.outLinks = [];
        this.output = 0;
        this.gradient = 0;
        this.kernel = new Kernel(numInputs);
    }
    feedForward() {
        this.output = this.kernel.similarity(this.inputs);
    }
    propagateBackward(prev) {
        var which = this.inputs.indexOf(prev);
        return this.kernel.propagate(which, this.gradient);
    }
    connectInput(i, prev) {
        this.inputs[i] = prev;
        prev.outLinks.push(this);
    }
    connectInputs(prevs) {
        for (var i = 0; i < this.inputs.length; i++) {
            this.connectInput(i, prevs[i]);
        }
    }
    getBackGradients() {
        var grad = 0.0, self = this;
        this.outLinks.forEach(node => grad += node.propagateBackward(self));
        return grad;
    }
    learn() {
        var backGrad = this.getBackGradients();
        this.gradient = backGrad * this.kernel.derivative(this.inputs);
        this.kernel.learn(this.inputs, this.gradient);
    }
    update() {
        this.kernel.update();
    }
}
exports.Neuron = Neuron;
class OutputNeuron extends Neuron {
    constructor(numInputs) {
        super(numInputs);
    }
    setGold(value) {
        this.gold = value;
    }
    getBackGradients() {
        return this.gold - this.output; // when objective function is squre error
    }
}
class MLP {
    constructor(layerSizes) {
        if (!layerSizes)
            return;
        this.layers = new Array(layerSizes.length);
        for (var i = 0; i < this.layers.length; i++) {
            if (i == 0) {
                this.createInputNodes(layerSizes[i]); // input layer
            }
            else if (i < this.layers.length - 1) {
                this.createLayerNeurons(i, layerSizes[i], layerSizes[i - 1]);
            }
            else {
                this.createOutputNeurons(i, layerSizes[i], layerSizes[i - 1]);
            }
        }
    }
    createInputNodes(numNodes) {
        var nodes = this.layers[0] = new Array(numNodes);
        for (var j = 0; j < nodes.length; j++) {
            nodes[j] = new Neuron();
        }
    }
    createLayerNeurons(layer, numNodes, numInputs) {
        var nodes = this.layers[layer] = new Array(numNodes);
        for (var j = 0; j < nodes.length; j++) {
            nodes[j] = new Neuron(numInputs);
        }
        this.setInputNeurons(layer);
    }
    createOutputNeurons(layer, numNodes, numInputs) {
        var nodes = this.layers[layer] = new Array(numNodes);
        for (var j = 0; j < nodes.length; j++) {
            nodes[j] = this.createOutputNeuron(numInputs);
        }
        this.setInputNeurons(layer);
    }
    createOutputNeuron(numInputs) {
        return new OutputNeuron(numInputs);
    }
    setInputNeurons(layer) {
        var prevs = this.layers[layer - 1];
        this.layers[layer].forEach(node => node.connectInputs(prevs));
    }
    getLayer(index) {
        return (index < 0 || index >= this.layers.length) ? null : this.layers[index];
    }
    getOutputLayer() {
        return this.layers[this.layers.length - 1];
    }
    // train(samples:Sample[], iterNum:number, batchSize:number):MLP {
    train(samples, iterNum, batchSize) {
        mlp.eps = mlp.epsDefault / batchSize;
        for (var iter = 0; ++iter <= iterNum;) {
            var error = 0.0;
            var index = 0, numSamples = samples.getNumSamples(); //samples.length; //
            while (index < numSamples) {
                for (var i = 0; i < batchSize; i++) {
                    var sample = samples.getSample(index++); //samples[index++];//
                    this.feedForward(sample.input);
                    this.learnBackward(sample.output);
                    error += this.findError(sample.output);
                    if (index >= numSamples)
                        break;
                }
                this.update();
            }
            if (mlp.debug && iter % mlp.debugCount == 0) {
                error /= numSamples;
                console.log(iter + "\terror = " + error);
            }
        }
        return this;
    }
    feedForward(input) {
        for (var j = 0; j < input.length; j++) {
            this.layers[0][j].output = input[j];
        }
        for (var i = 1; i < this.layers.length; i++) {
            this.layers[i].forEach(node => node.feedForward());
        }
    }
    learnBackward(gold) {
        var nodes = this.getOutputLayer();
        for (var i = 0; i < gold.length; i++) {
            nodes[i].setGold(gold[i]);
        }
        for (var i = this.layers.length - 1; i > 0; i--) {
            this.layers[i].forEach(node => node.learn());
        }
    }
    update() {
        for (var i = 1; i < this.layers.length; i++) {
            this.layers[i].forEach(node => node.update());
        }
    }
    argmax(nodes) {
        var max = Number.NEGATIVE_INFINITY;
        var argmax = -1;
        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].output > max) {
                max = nodes[i].output;
                argmax = i;
            }
        }
        return argmax;
    }
    findGoldLabel(out) {
        var argmax = -1;
        var max = Number.NEGATIVE_INFINITY;
        for (var i = 0; i < out.length; i++) {
            if (out[i] > max) {
                max = out[i];
                argmax = i;
            }
        }
        return argmax;
    }
    findError(gold) {
        var nodes = this.getOutputLayer();
        var sum = 0.0;
        for (var j = 0; j < nodes.length; j++) {
            sum += Math.abs(nodes[j].output - gold[j]);
        }
        return sum / nodes.length;
    }
    classify(feature) {
        this.feedForward(feature);
        var nodes = this.getOutputLayer();
        var outputs = nodes.map(node => node.output);
        console.log(feature + ' : ' + outputs);
        return nodes.length > 1 ? this.argmax(nodes) :
            (nodes[0].output > 0.5 ? 1 : 0);
    }
    evaluate(samples) {
        var accuracy = 0, total = 0;
        samples.forEach(sample => {
            var result = this.classify(sample.input);
            var gold = (sample.output.length > 1) ? this.findGoldLabel(sample.output)
                : (sample.output[0] > 0.5 ? 1 : 0);
            // console.log(sample.input +' result '+ gold + ' gold ' + gold);
            if (result == gold)
                accuracy++;
            total++;
        });
        console.log(accuracy + " / " + total + ", accuracy " + (accuracy * 100.0 / total) + "%");
    }
}
exports.MLP = MLP;
