/*
This program is for demonstrating the concept of multi-layer perceptrons.
Two examples are given: one is the parity check task and the other is the iris
classification task.

Author: Bor-Shen Lin at National Taiwan University of Science and Technology
*****************************************************************************
Genesis 1:1 In the beginning God created the heavens and the earth.
*/

declare function require(name:string);

export module mlp {
  export var eps = 0.1;
  export var epsDefault = 0.1;
  export var debug:boolean = true;
  export var debugCount:number = 10;
  export var momentum:boolean = true;

}

export class Sample {
  input:number[];
  output:number[];
  constructor(input:number[], output:number[]){
    this.input = input;
    this.output = output;
  }
}
export interface DataSource {
  getNumSamples():number;
  getSample(i:number):Sample;
}
export class Samples implements DataSource {
  constructor(public samples:Sample[]){}
  getNumSamples():number{return this.samples.length;}
  getSample(i:number):Sample {
    return this.samples[i];
  }
}
interface Activation {
  get(x:number):number;
  derivative(y:number):number;
}

class Sigmoid {
  get(x:number):number {
    return 1 / (1 + Math.exp(-x));
  }
  derivative(y:number):number {
    return y * (1.0 - y); // only for sigmoid: f'(x) = f(x)*(1-f(x))
  }
}

class Kernel {
  w:number [];
  b:number;
  _w:number[]; // for min-batch (accumulated update)
  _b:number;
  __w:number[]; // for momentum
  __b:number;
  activation:Activation;
  constructor(numInputs:number) {
    this.w = new Array(numInputs);
    this._w = new Array(numInputs);
    this.__w = new Array(numInputs);
    for(var i = 0; i < this.w.length; i++) {
      this.w[i] = (Math.random()-0.5)*2; // (-1,1)
      this._w[i] = 0;
      this.__w[i] = 0;
    }
    this.b = (Math.random()-0.5)*2;
    this._b = 0;
    this.__b = 0;
    this.activation = new Sigmoid();
  }
  similarity(inputs:Neuron[]) {
		var sum = this.b;
		for (var i = 0; i < inputs.length; i++) {
			sum += this.w[i] * inputs[i].output;
		}
		return this.activation.get(sum);
	}
	derivative(inputs:Neuron[]):number {
    var y = this.similarity(inputs);
		return this.activation.derivative(y);
	}
	propagate(index:number, grad:number) {
		return this.w[index] * grad;
	}
  learn(inputs:Neuron[], grad:number) {
    for (var i = 0; i < this._w.length; i++) {
      this._w[i] += grad * inputs[i].output;
    }
    this._b += grad;
  }
  update() {
      for (var i = 0; i < this.w.length; i++) {
          if (mlp.momentum && this._w[i] * this.__w[i] > 0.0) {
              this._w[i] += this.__w[i];
          }
          this.w[i] += mlp.eps * this._w[i];
      }
      if (mlp.momentum && this._b * this.__b > 0.0) {
          this._b += this.__b;
      }
      this.b += mlp.eps * this._b;
      for (var i = 0; i < this._w.length; i++) {
          this.__w[i] = this._w[i];
          this._w[i] = 0.0;
      }
      this.__b = this._b;
      this._b = 0.0;
  }
}

export class Neuron {
  inputs: Neuron[];
  outLinks: Neuron[];
  output:number;
  gradient:number;
  kernel:Kernel;
  constructor(numInputs?:number){
    this.inputs = new Array(numInputs);
    this.outLinks = [];
    this.output = 0;
    this.gradient = 0;
    this.kernel = new Kernel(numInputs);
  }
  feedForward() {
    this.output = this.kernel.similarity(this.inputs);
  }
  propagateBackward(prev:Neuron):number {
    var which = this.inputs.indexOf(prev);
    return this.kernel.propagate(which, this.gradient);
  }
  connectInput(i:number, prev:Neuron) {
		this.inputs[i] = prev;
		prev.outLinks.push(this);
	}
	connectInputs(prevs: Neuron[]) {
		for (var i = 0; i < this.inputs.length; i++) {
			this.connectInput(i, prevs[i]);
		}
	}
  getBackGradients():number {
  	var grad = 0.0, self = this;
    this.outLinks.forEach(node => grad += node.propagateBackward(self));
  	return grad;
  }
  learn() {
		var backGrad:number = this.getBackGradients();
		this.gradient =  backGrad * this.kernel.derivative(this.inputs);
		this.kernel.learn(this.inputs, this.gradient);
	}
	update() {
		this.kernel.update();
	}
}

class OutputNeuron extends Neuron {

    gold:number;

    constructor(numInputs:number) {
        super(numInputs);
    }

    setGold(value:number) {
        this.gold = value;
    }

    getBackGradients():number {
    	return this.gold - this.output; // when objective function is squre error
    }
}

export class MLP {
	layers:Neuron[][];
  constructor(layerSizes:number[]) {
    if(!layerSizes) return;
		this.layers = new Array(layerSizes.length);
		for (var i = 0; i < this.layers.length; i++) {
			if (i == 0) {
				this.createInputNodes(layerSizes[i]);  // input layer
			} else if (i < this.layers.length - 1) {
				this.createLayerNeurons(i, layerSizes[i], layerSizes[i - 1]);
			} else {
				this.createOutputNeurons(i, layerSizes[i], layerSizes[i - 1]);
			}
		}
	}

	createInputNodes(numNodes:number) {
		var nodes = this.layers[0] = new Array(numNodes);
		for (var j = 0; j < nodes.length; j++) {
			nodes[j] = new Neuron();
		}
	}

	createLayerNeurons(layer:number, numNodes:number, numInputs:number) {
		var nodes = this.layers[layer] = new Array(numNodes);
		for (var j = 0; j < nodes.length; j++) {
			nodes[j] = new Neuron(numInputs);
		}
		this.setInputNeurons(layer);
	}

	createOutputNeurons(layer:number, numNodes:number, numInputs:number) {
		var nodes= this.layers[layer] = new Array(numNodes);
		for (var j = 0; j < nodes.length; j++) {
			nodes[j] = this.createOutputNeuron(numInputs);
		}
		this.setInputNeurons(layer);
	}

  createOutputNeuron(numInputs:number): Neuron {
		return new OutputNeuron(numInputs);
	}

	setInputNeurons(layer:number) {
    var prevs = this.layers[layer - 1];
    this.layers[layer].forEach(node => node.connectInputs(prevs));
	}

	getLayer(index:number): Neuron[] {
		return (index < 0 || index >= this.layers.length) ? null : this.layers[index];
	}

	getOutputLayer():Neuron[] {
		return this.layers[this.layers.length - 1];
	}

  // train(samples:Sample[], iterNum:number, batchSize:number):MLP {
  train(samples:DataSource, iterNum:number, batchSize:number):MLP {
		mlp.eps =  mlp.epsDefault / batchSize;
		for (var iter = 0; ++iter <= iterNum; ) {
			var error = 0.0;
      var index = 0, numSamples = samples.getNumSamples();//samples.length; //
      while(index < numSamples) {
        for (var i = 0; i < batchSize; i++) {
  				var sample:Sample = samples.getSample(index++); //samples[index++];//
  				this.feedForward(sample.input);
  				this.learnBackward(sample.output);
          error += this.findError(sample.output);
          if(index >= numSamples) break;
  			}
  			this.update();
      }
			if (mlp.debug && iter % mlp.debugCount == 0) {
				error /= numSamples;
				console.log(iter + "\terror = " + error);
			}
		}
    return this;
	}

  feedForward(input:number[]) {
		for (var j = 0; j < input.length; j++) {
			this.layers[0][j].output = input[j];
		}
		for (var i = 1; i < this.layers.length; i++) {
			this.layers[i].forEach(node => node.feedForward());
		}
	}

  learnBackward(gold: number[]) {
    var nodes = this.getOutputLayer();
		for(var i = 0; i < gold.length; i++) {
      (nodes[i] as OutputNeuron).setGold(gold[i]);
    }
		for (var i = this.layers.length - 1; i > 0; i--) {
			this.layers[i].forEach(node => node.learn());
		}
	}

	update() {
		for (var i = 1; i < this.layers.length; i++) {
			 this.layers[i].forEach(node => node.update());
		}
	}

  argmax(nodes: Neuron[]): number {
		var max = Number.NEGATIVE_INFINITY;
		var argmax = -1;
		for (var i = 0; i < nodes.length; i++) {
			if (nodes[i].output > max) {
				max = nodes[i].output;
				argmax = i;
			}
		}
		return argmax;
	}

  findGoldLabel(out:number[]):number {
		var argmax = -1;
		var max = Number.NEGATIVE_INFINITY;
		for (var i = 0; i < out.length; i++) {
			if (out[i] > max) {
				max = out[i];
				argmax = i;
			}
		}
		return argmax;
	}

  findError(gold:number[]):number {
		var nodes = this.getOutputLayer();
		var sum = 0.0;
		for (var j = 0; j < nodes.length; j++) {
			sum += Math.abs(nodes[j].output - gold[j]);
		}
		return sum / nodes.length;
	}

  classify(feature:number[]):number {
  	this.feedForward(feature);
  	var nodes:Neuron[] = this.getOutputLayer();
    var outputs:number[] = nodes.map(node => node.output);
    console.log(feature +' : '+ outputs);
  	return nodes.length > 1 ? this.argmax(nodes) :
      (nodes[0].output > 0.5 ? 1 : 0);
	}

	evaluate(samples:Sample[]) {
    var accuracy = 0, total = 0;
    samples.forEach(sample => {
        var result = this.classify(sample.input);
        var gold = (sample.output.length > 1) ? this.findGoldLabel(sample.output)
                          : (sample.output[0] > 0.5 ? 1 : 0);
        // console.log(sample.input +' result '+ gold + ' gold ' + gold);
        if (result == gold) accuracy++;
        total++;
    });
    console.log(accuracy + " / " + total + ", accuracy " + (accuracy * 100.0 / total) +"%");
	}
}
