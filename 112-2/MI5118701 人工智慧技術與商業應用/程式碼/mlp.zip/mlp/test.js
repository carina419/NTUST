"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require('fs');
// var mlp = require('./mlp');
const mlp_1 = require("./mlp");
// eorTest();
// parityTest();
// regressorTest();
irisTest('iris.csv');
// main();
function main() {
    let cfgFile = 'mlp.json';
    for (let i = 2; i < process.argv.length; i++)
        eval(process.argv[i]);
    let config = require(cfgFile); // require a json e.g. ./loan
    let samples = config.samples.map(sample => new mlp_1.Sample(sample[0], sample[1]));
    console.log(config.layers);
    mlp_1.mlp.debug = false;
    let model = new mlp_1.MLP(config.layers).train(new mlp_1.Samples(samples), config.epochs, config.batchSize);
    if (config.regressor) {
        samples.forEach(sample => {
            model.feedForward(sample.input);
            var nodes = model.getOutputLayer();
            var outputs = nodes.map(node => node.output);
            console.log(sample.input + ' : ' + outputs);
        });
    }
    else
        model.evaluate(samples); // classifier
}
function eorTest() {
    var samples = [
        new mlp_1.Sample([0, 0], [0]),
        new mlp_1.Sample([0, 1], [1]),
        new mlp_1.Sample([1, 0], [1]),
        new mlp_1.Sample([1, 1], [0])
    ];
    var model = new mlp_1.MLP([2, 6, 6, 1]);
    model.train(new mlp_1.Samples(samples), 1000, samples.length);
    model.evaluate(samples);
}
function parityTest() {
    var samples = [
        new mlp_1.Sample([0, 0, 0], [0]),
        new mlp_1.Sample([0, 0, 1], [1]),
        new mlp_1.Sample([0, 1, 0], [1]),
        new mlp_1.Sample([1, 0, 0], [1]),
        new mlp_1.Sample([0, 1, 1], [0]),
        new mlp_1.Sample([1, 1, 0], [0]),
        new mlp_1.Sample([1, 0, 1], [0]),
        new mlp_1.Sample([1, 1, 1], [1])
    ];
    var model = new mlp_1.MLP([3, 6, 6, 1]);
    model.train(new mlp_1.Samples(samples), 1000, samples.length);
    model.evaluate(samples);
}
function regressorTest() {
    var samples = [
        new mlp_1.Sample([0, 0, 0], [0]),
        new mlp_1.Sample([0, 0, 1], [0.1]),
        new mlp_1.Sample([0, 1, 0], [0.2]),
        new mlp_1.Sample([1, 0, 0], [0.3]),
        new mlp_1.Sample([0, 1, 1], [0.4]),
        new mlp_1.Sample([1, 1, 0], [0.5]),
        new mlp_1.Sample([1, 0, 1], [0.6]),
        new mlp_1.Sample([1, 1, 1], [0.7])
    ];
    var model = new mlp_1.MLP([3, 6, 6, 1]);
    model.train(new mlp_1.Samples(samples), 3000, samples.length);
    samples.forEach(sample => {
        model.feedForward(sample.input);
        var nodes = model.getOutputLayer();
        var outputs = nodes.map(node => node.output);
        console.log(sample.input + ' : ' + outputs);
    });
}
function irisTest(irisFile) {
    var labels = ['setosa', 'versicolor', 'virginica']; // 3 classes
    var samples = [];
    fs.readFile(irisFile, 'utf-8', (err, content) => {
        if (err)
            throw err;
        var lines = content.trim().split('\r\n');
        var titles = lines.shift();
        lines.map(line => line.trim())
            .filter(line => line)
            .forEach(line => {
            // if(line.trim() == '') return;
            var tokens = line.split(',');
            var label = tokens.pop(); // clazz label: 'setosa', 'versicolor', 'virginica'
            let clazz = labels.indexOf(label);
            // if(clazz < 0) {
            //   labels.push(label);
            //   clazz = labels.length - 1;
            // }
            // var clazz:number = labels.indexOf(label); // clazz index
            var output = [0, 0, 0];
            output[clazz] = 1;
            var input = tokens.map(item => parseFloat(item)); // strings converted to floats
            console.log(input + ' --> ' + output);
            samples.push(new mlp_1.Sample(input, output));
        });
        var model = new mlp_1.MLP([4, 6, 3]);
        model.train(new mlp_1.Samples(samples), 1000, samples.length);
        model.evaluate(samples);
    });
}
