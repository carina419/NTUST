import openai

openai.api_key = 'your openai key'


def ask_chatGPT(content: list):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        max_tokens=128,
        temperature=0.5,
        messages=content
    )
    return response.choices[0].message.content




