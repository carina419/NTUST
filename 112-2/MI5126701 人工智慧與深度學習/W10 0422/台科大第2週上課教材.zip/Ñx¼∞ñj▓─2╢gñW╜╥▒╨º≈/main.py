import pandas as pd
import streamlit as st
from st_aggrid import AgGrid, GridOptionsBuilder, ColumnsAutoSizeMode

import ask_openai as ao


st.set_page_config(layout="wide")
st.header('chatGPT應用')
df = pd.read_parquet('ta_feng_pchome_sample.parquet', engine='pyarrow')
customer_list = df.CUSTOMER_ID.to_numpy()
customer = st.selectbox(label='customer', options=customer_list[:10])
df = df[df['CUSTOMER_ID'] == customer][['TRANSACTION_DT',
                                        'PRODUCT_ID', 'PRODUCT_NAME', 'AMOUNT',
                                        'SALES_PRICE']]
option = GridOptionsBuilder.from_dataframe(df)
option.configure_selection(selection_mode="multiple", use_checkbox=True)
gridOptions = option.build()
selectin_item = AgGrid(df
                       , gridOptions=gridOptions
                       , columns_auto_size_mode=ColumnsAutoSizeMode.FIT_CONTENTS
                       , height=200)
selectin_item = [x["PRODUCT_NAME"] for x in selectin_item['selected_rows']]
promotion_item = st.text_input(label='想推銷商品')
if st.button(label='清除詢問結果'):
    st.session_state.clear()

st.write('---')
contain_1 = st.container()
with contain_1:
    text_ask1 = f"""
        請告訴我{"、".join(selectin_item)}和{promotion_item}的相似的性質，請列舉三項，直接給我答案即可。
    """
    st.subheader('提問一')
    st.write(text_ask1)
    if st.button(label='回應', key=1):
        st.session_state['ask_list'] = list()
        st.session_state['ask_list'].append({'role': 'user', 'content': text_ask1})
        ans_1 = ao.ask_chatGPT(st.session_state['ask_list'])
        st.session_state['ans_1'] = ans_1
        st.session_state['ask_list'].append({'role': 'assistant', 'content': ans_1})
    st.subheader('回應一')
    if 'ans_1' in st.session_state:
        st.write(st.session_state['ans_1'])
st.write('---')
contain_2 = st.container()
with contain_2:
    st.subheader('提問二')
    text_ask2 = f"""
        請針對以上特點，撰寫出一篇符合目前季節的廣告文案，但重點著重在「{promotion_item}」
    """
    st.write(text_ask2)
    if st.button(label='回應', key=2):
        st.session_state['ask_list'].append({'role': 'user', 'content': text_ask2})
        ans_2 = ao.ask_chatGPT(st.session_state['ask_list'])
        st.session_state['ans_2'] = ans_2
        st.session_state['ask_list'].append({'role': 'assistant', 'content': ans_2})
    st.subheader('回應二')
    if 'ans_2' in st.session_state:
        st.write(st.session_state['ans_2'])
st.write('---')
contain_3 = st.container()
with contain_3:
    st.subheader('提問三')
    text_ask3 = f"""
        請將上述內容濃縮在70個字以內。
    """
    st.write(text_ask3)
    if st.button(label='回應', key=3):
        st.session_state['ask_list'].append({'role': 'user', 'content': text_ask3})
        ans_3 = ao.ask_chatGPT(st.session_state['ask_list'])
        st.session_state['ans_3'] = ans_3
    st.subheader('回應三')
    if 'ans_3' in st.session_state:
        st.write(st.session_state['ans_3'])
